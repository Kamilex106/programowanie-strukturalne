#include <stdio.h>
#include <stdlib.h>

void wyczysc(char *napis)
{
    napis[0]=0;
}
int main()
{
    printf("new 5.2.1\n");
    char *napis="pieczewo";
    printf(napis);
    printf("\n");
    printf("co nam wyswietli po wyczyszczeniu");
    wyczysc(napis);
    printf(napis);
    free(napis);

}
