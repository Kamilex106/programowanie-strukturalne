#include <stdio.h>
#include <stdlib.h>

int dlugosc(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         i++;
     }
     return i;
}


void kopiujn(char*napis1,char*napis2, unsigned int n)
{
    int i;
    for(i=0;i<dlugosc(napis1)&&i<n;i++)
    {
        napis2[i]=napis1[i];
    }
    napis2[i]=0;
}

void wypisz(char *napis)
{
    printf("%s\n",napis);
}




int main()
{
    char* pierwszy = "arbuz";
    char drugi[20] = "arbiter";
    wypisz(pierwszy);
    wypisz(drugi);
    printf(pierwszy);
    printf("\n");
    printf(drugi);
    printf("\n");
    kopiujn(pierwszy,drugi,3);

    ///

    char* piaty= "student";
    char* szosty=malloc(20*sizeof(char)); //alokacja pamieci na szostego
    wypisz(piaty);
    kopiujn(piaty,szosty,3);
    wypisz(piaty);
    wypisz(szosty);


    char *pierwszy6 = "informatyka";

    return 0;
}


