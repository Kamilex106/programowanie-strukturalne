#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int dlugosc(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         i++;
     }
     return i;
}


int porownaj(char *napis, char *napis2)
{
    int i=0;
    bool czy_rowne = true;
    if (czy_rowne == true)
    {
            while(napis[i] == napis2[i] && czy_rowne)
     {
         {
             i++;
         }

     }
    }
    else
    {
        czy_rowne = false;
    }

    return 1;
}



int porownajnapisy(char *napis1,char *napis2)
{
    int i;
    int dl1=dlugosc(napis1);
    int dl2=dlugosc(napis2);
    if (dl1==dl2)
    {
        for(i=0;i<=dl2-1;i++)
        {
            if (napis1[i]!=napis2[i])
            {
                return 0;
            }

        }
        return 1;
    }
    else
    {
        return 0;
    }

    }








int main()
{

    printf(porownajnapisy("woda","woda"));
    return 0;
}
