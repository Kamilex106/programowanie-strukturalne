#include <stdio.h>
#include <stdlib.h>


int dlugosc(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         i++;
     }
     return i;
}

int porownajnapisy(char *napis1,char *napis2)
{
    int i;
    int dl1=dlugosc(napis1);
    int dl2=dlugosc(napis2);
    if (dl1 > dl2)
    {
        return 0;
    }
    int wiekszy =0;
    if (dl1>dl2)
    {
        wiekszy = dl1;
    }
    else
    {
        wiekszy = dl2;
    }
        for(i=0;i<=wiekszy-1;i++)
        {
            if (napis1[i]>napis2[i])
            {
                return 0;
            }

        }
        return 1;
    }

    int porownajslownikowo(char *napis1,char *napis2)
    {
        int i,x;
        for (i=0;napis1[i]!=0 ||  napis2[i]!=0;i++)
        {
            if (napis1[i]==0 && napis2[i] !=0)
            {
                return 0;
            }
            if (napis1[i]!=0 && napis2[i] ==0)
            {
                return 1;
            }
            if (napis1[i]==0 && napis2[i] == 0)
            {
                for (x=0;napis1[x]!=0;x++)
                {
                    if (napis1[x]<napis2[x] == 0)
                    {
                        return 0;
                    }
                }
            }
        }
        return 1;
    }

int porownajslownikowo2(char *napis1,char *napis2)
    {
        int i;
        if (porownajnapisy(napis1,napis2)==1)
        {
            return 0;
        }
        for (i=0;napis1[i]!=0 &&  napis2[i]!=0;i++)
        {
            if (napis1[i] != napis2[i])
            {
                if (napis1[i]<napis2[i])
                {
                    return 1;
                }
                else if (napis1[i]>napis2[i])
                {
                    return 0;
                }
    }
    }
    if (napis1[i]!=0)
    {
        return 0;
    }
    if (napis2[i]!=0)
    {
        return 1;
    }
    }









int main()
    {
     printf("%d\n",porownajslownikowo2("arbiter","arbuz")); //1
     printf("%d\n",porownajslownikowo2("arbuz","arbiter")); //0
     printf("%d\n",porownajslownikowo2("baba","alibaba")); //0
     printf("%d\n",porownajslownikowo2("hulajdusza","hulajnoga")); //1
     printf("%d\n",porownajslownikowo2("sama","sam")); //0
     printf("%d\n",porownajslownikowo2("sam","sama")); //1
     printf("%d\n",porownajslownikowo2("matematyka","matematyka")); //0
     return 0;
}
