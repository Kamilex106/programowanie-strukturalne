#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
struct trojkat
{
    double a,b,c;
};

double obwod(struct trojkat t)
{
    return t.a+t.b+t.c;
}

double pole(struct trojkat t)
{
    int p = (t.a+t.b+t.c)/2;
    return sqrt(p*(p-t.a)*(p-(t.b)*(p-(t.c))));
}

bool czy_tworza(struct trojkat t)
{
    bool czy =0;
    if (t.a!=0 && t.b!= 0 && t.c!=0)
    {
        if ((t.a) < (t.b + t.c))
        {
            if ((t.b) < (t.a + t.c))
                {
                    if ((t.c) < (t.a + t.b))
                    {
                        czy =1;
                    }
                    else {
                        czy = 0;
                    }
                }
        }
    }






    return czy;
}




void przepisz(struct trojkat t1, struct trojkat *t2)
{
    *t2=t1;
}


void wypisz(struct trojkat tr1)
{
    printf("%f\n",tr1.a);
    printf("%f\n",tr1.b);
    printf("%f\n",tr1.c);

}


//void przepisz(struct trojkat tr1)
//{
  //  printf("%f\n",tr1.a);
    //printf("%f\n",tr1.b);
    //printf("%f\n",tr1.c);

//}




struct punkt
{
    double x,y,z;
};

struct punkt2
{
    double x,y,z;
};



double odleglosc(struct punkt t1, struct punkt2 t2)
{
    return sqrt((((t2.x-t1.x)*(t2.x-t1.x))+((t2.y-t1.y)*(t2.y-t1.y))+((t2.z-t1.z)*(t2.z-t1.z))));
}


double minimum(struct punkt tab[], int n)
{

    //odleglosc tab0- tab1
    int i,j;
    double pom;
    double min=sqrt(pow(tab[1].x-tab[0].x,2)+pow(tab[1].y-tab[0].y,2)+pow(tab[1].z-tab[0].z,2));
    for (i=0;i<n-1;i++)
    {
        for (j=i+1;j<n;j++)
        {
            pom = sqrt(pow(tab[j].x-tab[i].x,2)+pow(tab[j].y-tab[i].y,2)+pow(tab[j].z-tab[i].z,2));
        }
        if(pom<min)
        {
            min=pom;
        }
    }
    return min;
}


struct zespolone
{
    double im,re;
};


double dodaj()












int main()
{
    struct trojkat tr1;
    tr1.a=3;
    tr1.b=4;
    tr1.c=5;

    struct trojkat tr2;
    tr2.a=1;
    tr2.b=1;
    tr2.c=1;

    struct trojkat *wsk2=&tr2;
    wypisz(tr1);
    wypisz(tr2);
    przepisz(tr1,wsk2);
    printf("Po zmianie\n");
    wypisz(tr1);
    wypisz(*wsk2);


    printf("Obwod: %f\n", obwod(tr1));
    printf("Pole: %f\n", pole(tr1));

    printf("%d\n",sizeof(double));
    printf("%d",sizeof(struct trojkat));





    struct punkt P;
    P.x=1;
    P.y=3;
    P.z=5;

    struct punkt Q;
    Q.x=4;
    Q.y=2;
    Q.z=9;

    struct punkt R;
    R.x=5;
    R.y=0;
    R.z=0;

    struct punkt tab[3]=(P,Q,R);
    printf("%f",minimum(tab,3));







//7.2.4 , 5 i 6 pd







    return 0;
}

// double min=odleglosc(pow(tab[1].x-tab[0].x,2)+pow(tab[1].y-tab[0].y,2)+pow(tab[1].z-tab[0].z);
