#include<stdio.h>
#include<stdlib.h>
//uklad trzech rownan z 3 niewiadomymi (tu: 2)
int main()
{

int a,b,c,d,e,f;
int W,Wx,Wy;
float x,y;
scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
printf("Zdefiniowales uklad rownan \n%d*x+%d*y=%d\n %d*x+%d*y=%d",a,b,c,d,e,f);
W = a*e-b*d;
Wx = c*e-b*f;
Wy = a*f-c*d;
if(W!=0)
{
  x=(float)(Wx)/W;
 y=(float)(Wy)/W;
 printf("\nRozwiazaniem ukladu rownan jest x=%f,y=%f",x,y);
}
else if(Wx==0&&Wy==0)
{
  printf("Uklad nieoznaczony");
}
else
{
  printf("Uklad sprzeczny");
}
return 0;
}
