#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    printf("Podaj 3 liczby calkowite:\n");
    scanf("%d %d %d",&a,&b,&c);
    printf("Wypisane 3 liczby: \n%d\n%d\n%d",a,b,c);
}
