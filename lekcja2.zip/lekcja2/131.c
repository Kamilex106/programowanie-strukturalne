#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x;
    printf("\nPodaj liczbe calkowita:\n");
    scanf("%d",&x);
    printf("Wartosc bezgledna z liczby %d wynosi ",x);
    if(x>=0)
    {
        printf("%d",x);
    }
    else
    {
         printf("%d",-x);
    }
    return 0;
}
