#include <stdio.h>

unsigned int podlogazpierwiastka(unsigned int x)
{
  int i;
  for(i = 0; i * i <= x; i++)
  {

  }
  return i - 1;
}

int main()
{
  int n;
  scanf("%d",&n);
  printf("podloga z pierwiastka (%d) = %d",n,podlogazpierwiastka(n));
  return 0;
}
