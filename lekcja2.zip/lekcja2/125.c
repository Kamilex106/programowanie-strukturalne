#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("Bardzo\ndlugi\nnapis\n");
    printf("Napis zawierajacy rozne dziwne znaczki // \\ \\ $ & %%\n");
    int x;

    printf("Podaj liczbe calkowita:\n");
    scanf("%d",&x);
    printf("Liczba = %d. Powtorzona to %d",x,x);

    float w;
    printf("\nPodaj liczbe wymierna:\n");
    scanf("%f",&w);
    printf("Liczba wymierna = %.2f",w);
    return 0;
}
