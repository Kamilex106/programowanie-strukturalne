#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    printf("Podaj 3 liczby calkowite:\n");
    scanf("%d",&x);
    printf("Po dodaniu: %d",x+1);
}
