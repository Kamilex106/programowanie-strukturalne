#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    printf("\nPodaj liczbe wymierna:\n");
    scanf("%d",&x);
    printf("Wartosc bezgledna z liczby %d wynosi %d",x,abs(x));
    return 0;
    // dla float %f fabs(x)
}
