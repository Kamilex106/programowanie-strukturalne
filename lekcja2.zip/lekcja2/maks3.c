#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x,y,z;
    printf("\nPodaj liczby calkowite:\n");
    scanf("%d %d %d",&x,&y,&z);
    printf("Maksimum z liczb x y z wynosi ",x,y,z);
    if(x>=y && x>=z)
    {
        printf("%d",x);
    }
    else if(y>=z)
    {
         printf("%d",y);
    }
     else
    {
         printf("%d",z);
    }
    return 0;
}
