#include <stdio.h>
#include <stdlib.h>

int main()
{
    float average;
    int a,b,c;
    printf("Podaj 3 liczby calkowite:\n");
    scanf("%d %d %d",&a,&b,&c);
    average = (a+b+c)/3;
    printf("Srednia: %0.1f",average);
}
