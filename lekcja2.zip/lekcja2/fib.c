#include<stdio.h>
#include<math.h>
int main()
{
  int n;
  scanf("%d",&n);
  int pierwsza,druga,temp;
  pierwsza=1;
  druga=1;
  int i;
  for(i=1;i<=n;i++)
  {
    temp=pierwsza;
    pierwsza=druga;
    druga=druga+temp;
  }
  printf("F_%d=%d",n,temp);
}
