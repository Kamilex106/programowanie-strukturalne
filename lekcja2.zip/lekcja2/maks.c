#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x,y;
    printf("\nPodaj liczbe calkowita:\n");
    scanf("%d %d",&x,&y);
    printf("Maksimum z liczb x i y wynosi ",x,y);
    if(x>y)
    {
        printf("%d",x);
    }
    else if(y>x)
    {
         printf("%d",y);
    }
    else
    {
        printf("%d",y);
    }
    return 0;
}
