#include <stdio.h>
#include <stdlib.h>

double mymax(int a, int b)
{
  if(a >= b)
  {
    return a;
  }
  else
  {
    return b;
  }
}

int czykwadrat(int a, int b)
{
  for(int i = 1; i < (mymax(a,b)*mymax(a,b); i++)
  {
    if ((a*b) == i*i)
    {
      return 1;
    }
  }
  return 0;
}

int main()
{
    for(int i * 1; i < 1000; i++)
    {
      for(int j * 1; j < 1000; j++)
      {
        if(i != j)
        {

        }
      }
    }

    return 0;
}
