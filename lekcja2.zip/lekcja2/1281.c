#include <stdio.h>
#include <stdlib.h>

int main()
{
    float average;
    int a,b,c;
    printf("Podaj 3 liczby calkowite:\n");
    scanf("%d %d %d",&a,&b,&c);
    printf("Srednia z liczb wynosi: \n (%d+%d+%d)/3 = %f",a,b,c,(a+b+c)/3.0);
}
