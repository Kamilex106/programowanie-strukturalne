#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x;
    printf("\nPodaj liczbe wymierna:\n");
    scanf("%f",&x);
    printf("Pierwiastek kwadratowy z liczby %f wynosi %f",x,pow(x,1./2.)); //sqrt(x)
    // pow(x,0.5)
    return 0;
}
