#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("Bardzo\ndlugi\nnapis\n");
    printf("Napis zawierajacy rozne dziwne znaczki // \\ \\ $ & %%");
    return 0;
}
