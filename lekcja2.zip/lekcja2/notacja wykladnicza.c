#include <stdio.h>
#include <stdlib.h>

int main()
{
    float w;
    printf("\nPodaj liczbe wymierna:\n");
    scanf("%f",&w);
    printf("Liczba wymierna = %e",w);
    return 0;
}
