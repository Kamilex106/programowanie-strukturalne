#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int j;
    printf("\nPodaj liczbe calkowita:\n");
    scanf("%d",&j);
    printf("Signum z liczby %d wynosi ",j);
    if(j>=0)
    {
        printf("1");
    }
    else if(j==0)
    {
         printf("0");
    }
    else
    {
        printf("-1");
    }
    return 0;
}
