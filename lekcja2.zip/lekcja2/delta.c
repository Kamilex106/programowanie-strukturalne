#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{

int a,b,c,d;
float x1,x2;
scanf("%d %d %d",&a,&b,&c);
printf("Zdefiniowales rownanie %d*x^2+%d*x+%d=0",a,b,c);
d=b*b-4*a*c;
if(d>0)
{
  x1=(-b-sqrt(d)/(2*a));
  x2=(-b+sqrt(d)/(2*a));
  printf("\nRozwiazaniem rownania sa x1=%f, x2=%f",x1,x2);
}
else if(d==0)
{
  x1=(-b)/(2*a);
  printf("\nrozwiazaniem rownania sa x1=%f",x1);
}
else{
  printf("\nbrak rozwiazan");
}
return 0;
}
