#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x,y,z;
    printf("\nPodaj 3 liczby calkowite:\n");
    scanf("%d %d %d",&x,&y,&z);
    printf("Srodkowa z liczb %d %d %d wynosi ",x,y,z);
    if((x>=y) && (x<=z))
    {
        printf("%d",x);
    }
    else if(x==y)
    {
       printf("%d",x);
    }
     else if(x==z)
    {
       printf("%d",z);
    }
    else if(y>=x && y<=z)
    {
         printf("%d",y);
    }
     else
    {
         printf("%d",z);
    }
    return 0;
}
