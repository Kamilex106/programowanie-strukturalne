#include <stdio.h>
#include <stdlib.h>
int podloga(int x)
{
    int wynik;
    for(i=0;i*i<=x;i++);
    {

    }
    //opcjonalnie
    //while(i*i<=x)
    //{
    //i++
    //}
    return i-1;
}
int main()
{

    int n;
    scanf("%d",&n);
    printf("%d",podloga(n));
    return 0;

}
