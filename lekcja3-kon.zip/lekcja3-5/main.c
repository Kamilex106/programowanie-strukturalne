#include <stdio.h>
#include <stdlib.h>
//czynniki pierwsze
//dla wczytanej liczby stworz program w C ktory przedstawia liczbe za pomoca czynnikow pierwszych w postaci np. dla 300: 2^2+3+5^2


void rozklad(int liczba) {
    printf("%d = ", liczba);
    int czynnik = 2, potega = 0;
    while (liczba > 1) {
        if (liczba % czynnik == 0) {
            potega++;
            liczba /= czynnik;
        }

        else {
            if (potega == 1) {
                printf("%d * ", czynnik);
            } else if (potega > 1) {
                printf("%d^%d * ", czynnik, potega);
            }
            czynnik++;
            potega = 0;
        }
    }


    if (potega == 1) {
        printf("%d\n", czynnik);
    } else if (potega > 1) {
        printf("%d^%d\n", czynnik, potega);
    }
}

int main() {
    int n;
    printf("Podaj liczbe: ");
    scanf("%d", &n);
    rozklad(n);
    return 0;
}

