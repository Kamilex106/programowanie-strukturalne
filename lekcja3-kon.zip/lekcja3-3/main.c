#include <stdio.h>
#include <stdlib.h>
//znajdz liczby blizniacze pierwsze (pary liczb pierwszych rozniacych sie o 2) w zakresie do n (podane do fukcji) korzystajac z funkcji Czypierwsza


int CzyPierwsza(int liczba) {
    if (liczba == 1 || liczba == 2)
        return 1;
    for (int i = 2; i < liczba; i++) {
        if (liczba % i == 0)
            return 0;
    }
    return 1;
}

void znajdzLiczbyBlizniacze(int n) {
    for (int i = 2; i <= n; i++) {
        if (CzyPierwsza(i) && CzyPierwsza(i + 2)) {
            printf("%d i %d\n", i, i + 2);
        }
    }
}

int main() {
    int n;
    printf("Podaj zakres: ");
    scanf("%d", &n);
    znajdzLiczbyBlizniacze(n);
    return 0;
}
