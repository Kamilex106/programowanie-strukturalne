#include <stdio.h>
#include <stdlib.h>
//2^n dla naturalnych argumentow
float dwa_do_iks(int x)
{
    int i;
float wynik=1;
if(x>=0)
{
    for(i=1;i<=x;i++)
    {
        wynik=wynik/2
    }
}
return wynik;
}
}






//
//int silnia(int x)v
//{
//    int wynik=1;
//    int i;
//    for(i=1;i<=x;i++)
//    {
//        wynik=wynik*i;
//    }
//    return wynik;
//}
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    printf("2^%d=%d",n,dwa_do_iks(n));
//    return 0;
//}
//
//
//
//
//
//int silnia(int x)v
//{
//    int wynik=1;
//    int i;
//    for(i=1;i<=x;i++)
//    {
//        wynik=wynik*i;
//    }
//    return wynik;
//}
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    printf("%d!=%d",n,silnia(n));
//    return 0;
//}
//
