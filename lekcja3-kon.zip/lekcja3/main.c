#include <stdio.h>
#include <stdlib.h>
//bez mat
//napisz program w ktorym uzytkownik podaje 2 liczby co najwyzej 3 cyfrowe, ktorych iloczyn jest rowny kwadratowi i iloczyn powiekszony tych liczb o 1 tez ma byc kwadratem

int main() {
    int a, b, p1, p2;

    printf("Podaj dwie liczby co najwyzej trzycyfrowe:\n");
    scanf("%d %d", &a, &b);

    p1 = a * b;
    p2 = (a + 1) * (b + 1);


    if (sqrt(p1) == (int)sqrt(p1) && sqrt(p2) == (int)sqrt(p2)) {
            p1=(int)sqrt(p1);
            p2=(int)sqrt(p2);
        printf("Iloczyn %d i %d jest rowny kwadratowi %d, a iloczyn %d i %d powiekszony o 1 tez jest kwadratem %d.\n", a, b, p1, a, b, p2);
    } else {
        printf("Nie udalo sie znalezc liczb spelniajacych warunek.\n");
    }

    return 0;
}
