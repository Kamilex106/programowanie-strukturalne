#include <stdio.h>
#include <stdlib.h>
float dwa_do_x(int x)
{
if(x==0)
    return 1;
if(x>0)
    return 2*dwa_do_x(x-1);
if(x<0)
    return dwa_do_x(x+1)/2;
return 1/dwa_do_x(-x);
}


int main()
{
    int n;
    scanf("%d",&n);
    printf("%d",dwa_do_x(n));
    return 0;
}
