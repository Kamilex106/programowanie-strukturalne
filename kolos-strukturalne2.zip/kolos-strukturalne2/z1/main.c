#include <stdio.h>

int dlugosc(char* napis) {
    int dl = 0;
    while (napis[dl] != '\0') {
        dl++;
    }
    return dl;
}

char* zmodyfikuj_imie(char* Imie) {
    int ind = -2;
    for (int i = 0; i < dlugosc(Imie); i++) {
        if (Imie[i] == 32) {
            ind = i;
            Imie[i] = '.';
        }
        else if (i == 0) {
            if (Imie[i] >= 97 && Imie[i] <= 122) {
                Imie[i] -= 32;
            }
        }
        else if (i == ind + 1) {
            if (Imie[i] >= 97 && Imie[i] <= 122) {
                Imie[i] -= 32;
            }
        }
        else {
            if (Imie[i] >= 97 && Imie[i] <= 122) {
                Imie[i] -= 32;
            }
            else {
                Imie[i] += 32;
            }
        }
    }
    return Imie;
}

int main() {
    char imie[] = "KAMIL NOWAK";
    char* wynik = zmodyfikuj_imie(imie);
    printf("%s\n", wynik);
    return 0;
}
