#include <stdio.h>

void wyswietl_macierz(int m, int n, int** macierz) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", macierz[i][j]);
        }
        printf("\n");
    }
}

int suma_elementow_brzegowych(int m, int n, int** macierz) {
    int suma = 0;

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 || i == m - 1 || j == 0 || j == n - 1) {
                if (macierz[i][j] % 2 == 0) {
                    suma += macierz[i][j];
                }
            }
        }
    }

    return suma;
}

int main() {
    int m, n;

    printf("Podaj liczbe wierszy (m): ");
    scanf("%d", &m);

    printf("Podaj liczbe kolumn (n): ");
    scanf("%d", &n);


    int** macierz = (int**)malloc(m * sizeof(int*));
    for (int i = 0; i < m; i++) {
        macierz[i] = (int*)malloc(n * sizeof(int));
    }

    printf("Podaj elementy macierzy:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &macierz[i][j]);
        }
    }

    printf("Macierz:\n");
    wyswietl_macierz(m, n, macierz);

    int suma = suma_elementow_brzegowych(m, n, macierz);

    printf("Suma elementow parzystych na brzegu macierzy: %d\n", suma);


    for (int i = 0; i < m; i++) {
        free(macierz[i]);
    }
    free(macierz);

    return 0;
}
