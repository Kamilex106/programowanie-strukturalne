#include <stdio.h>
#include <stdlib.h>

// Struktura reprezentuj�ca pojedynczy element listy
typedef struct Node {
    int value;
    struct Node* next;
} Node;

// Funkcja do dodawania elementu na koniec listy
void addNode(Node** head, int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->value = value;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
    } else {
        Node* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

// Funkcja do zwalniania pami�ci zajmowanej przez list�
void freeList(Node** head) {
    Node* current = *head;
    Node* next;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

// Funkcja do tworzenia nowej listy na podstawie co drugiego elementu z oryginalnej listy
Node* getEverySecondElement(Node* head) {
    Node* newHead = NULL;
    Node* current = head;
    int count = 1;  // Zaczynamy od pierwszego elementu

    while (current != NULL) {
        if (count % 2 == 1) {  // Je�eli jest to element nieparzysty, dodajemy go do nowej listy
            addNode(&newHead, current->value);
        }
        count++;
        current = current->next;
    }

    return newHead;
}

// Funkcja do wy�wietlania zawarto�ci listy
void printList(Node* head) {
    Node* current = head;

    while (current != NULL) {
        printf("%d ", current->value);
        current = current->next;
    }

    printf("\n");
}

int main() {
    Node* head = NULL;

    // Dodajemy przyk�adowe elementy do listy
    addNode(&head, 1);
    addNode(&head, 5);
    addNode(&head, 8);
    addNode(&head, 7);
    addNode(&head, 2);

    printf("Oryginalna lista: ");
    printList(head);

    Node* newHead = getEverySecondElement(head);

    printf("Nowa lista: ");
    printList(newHead);

    freeList(&head);
    freeList(&newHead);

    return 0;
}
