#include <stdio.h>
#include <string.h>

void modifyString(char* str) {
    int len = strlen(str);
    char modified[2 * len];  // Tworzenie tablicy wynikowej o dwukrotnie wi�kszym rozmiarze ni� oryginalny napis

    int j = 0;
    for (int i = 0; i < len; i++) {
        if (i < len - 1 && (str[i] == 'a' && str[i+1] == 'b') || (str[i] == 'b' && str[i + 1] <= 'a')) {
            modified[j++] = str[i];
            modified[j++] = 'W';
        } else {
            modified[j++] = str[i];
        }
    }

    modified[j] = '\0';

    strcpy(str, modified);
}

int main() {
    char str[100];
    printf("Podaj napis: ");
    scanf("%s", str);

    modifyString(str);
    printf("Zmodyfikowany napis: %s\n", str);

    return 0;
}
