#include <stdio.h>

int obliczSumeParzystych(int m, int n, int **macierz) {
    int suma = 0;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 || i == m - 1 || j == 0 || j == n - 1) {
                if (macierz[i][j] % 2 == 0) {
                    suma += macierz[i][j];
                }
            }
        }
    }
    return suma;
}

int main() {
    // Przyk�adowa macierz 4x5
    int macierz[4][5] = {
        {1, 2, 3, 4, 5},
        {6, 7, 8, 9, 10},
        {11, 12, 13, 14, 15},
        {16, 17, 18, 19, 20}
    };

    int m = 4;
    int n = 5;
    int *wsk_macierz[4];

    // Tworzenie wska�nik�w do wierszy macierzy
    for (int i = 0; i < m; i++) {
        wsk_macierz[i] = macierz[i];
    }

    int suma = obliczSumeParzystych(m, n, wsk_macierz);
    printf("Suma parzystych elementow na brzegu macierzy: %d\n", suma);

    return 0;
}
