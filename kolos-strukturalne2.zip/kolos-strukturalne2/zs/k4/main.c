#include <stdio.h>

void odwrocKolumny(int arr[][3], int wiersze, int kolumny) {
    for (int kol = 0; kol < kolumny; kol++) {
        int start = 0;
        int koniec = wiersze - 1;

        while (start < koniec) {
            int temp = arr[start][kol];
            arr[start][kol] = arr[koniec][kol];
            arr[koniec][kol] = temp;
            start++;
            koniec--;
        }
    }
}

void przesunKolumny(int arr[][4], int wiersze, int kolumny) {
    for (int kol = kolumny - 1; kol >= 2; kol--) {
        for (int wier = 0; wier < wiersze; wier++) {
            int temp = arr[wier][kol];
            arr[wier][kol] = arr[wier][kol - 2];
            arr[wier][kol - 2] = temp;
        }
    }

    for (int kol = 0; kol < kolumny / 2; kol++) {
        for (int wier = 0; wier < wiersze; wier++) {
            int temp = arr[wier][kol];
            arr[wier][kol] = arr[wier][kolumny - kol - 1];
            arr[wier][kolumny - kol - 1] = temp;
        }
    }
}

void wypiszTablice(int arr[][4], int wiersze, int kolumny) {
    for (int wier = 0; wier < wiersze; wier++) {
        for (int kol = 0; kol < kolumny; kol++) {
            printf("%d ", arr[wier][kol]);
        }
        printf("\n");
    }
}

int main() {
    int arr1[][3] = {{1, 2, 3},
                     {4, 5, 6},
                     {7, 8, 9}};

    int arr2[][4] = {{1, 2, 3, 4},
                     {5, 6, 7, 8},
                     {9, 10, 11, 12}};

    int wiersze1 = sizeof(arr1) / sizeof(arr1[0]);
    int kolumny1 = sizeof(arr1[0]) / sizeof(int);

    int wiersze2 = sizeof(arr2) / sizeof(arr2[0]);
    int kolumny2 = sizeof(arr2[0]) / sizeof(int);

    printf("Przed odwr�ceniem kolumn:\n");
    wypiszTablice(arr1, wiersze1, kolumny1);
    odwrocKolumny(arr1, wiersze1, kolumny1);
    printf("\nPo odwr�ceniu kolumn:\n");
    wypiszTablice(arr1, wiersze1, kolumny1);

    printf("\nPrzed przesuni�ciem kolumn:\n");
    wypiszTablice(arr2, wiersze2, kolumny2);
    przesunKolumny(arr2, wiersze2, kolumny2);
    printf("\nPo przesuni�ciu kolumn:\n");
    wypiszTablice(arr2,wiersze2, kolumny2);
    return 0;
}
