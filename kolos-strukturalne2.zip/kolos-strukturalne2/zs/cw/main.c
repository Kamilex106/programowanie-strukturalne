#include <stdio.h>

void zamienSpacjeNaPodkreslenia(char* napis) {
    while (*napis) {
        if (*napis == ' ') {
            *napis = '_';
        }
        napis++;
    }
}

int main() {
    char napis[] = "To jest przykladowy napis";

    printf("Przed: %s\n", napis);
    zamienSpacjeNaPodkreslenia(napis);
    printf("Po: %s\n", napis);

    return 0;
}
