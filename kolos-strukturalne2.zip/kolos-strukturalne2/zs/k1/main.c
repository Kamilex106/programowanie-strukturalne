#include <stdio.h>
#include <stdlib.h>

char* modifyNameFormat(const char* name) {
    int length = 0;
    const char* temp = name;

    while (*temp != '\0') {
        length++;
        temp++;
    }

    char* modifiedName = (char*) malloc((length + 2) * sizeof(char));
    int i;
    int j = 0;
    char previousChar = ' ';

    for (i = 0; i < length; i++) {
        if (previousChar == ' ') {
            modifiedName[j] = (name[i] >= 'a' && name[i] <= 'z') ? name[i] - 'a' + 'A' : name[i];
            j++;
        } else if (previousChar != '.' && name[i] == ' ') {
            modifiedName[j] = '.';
            j++;
        } else if (previousChar != '.' && (name[i] >= 'A' && name[i] <= 'Z')) {
            modifiedName[j] = name[i] - 'A' + 'a';
            j++;
        } else if (previousChar != '.' && (name[i] >= 'a' && name[i] <= 'z')) {
            modifiedName[j] = name[i];
            j++;
        }

        previousChar = name[i];
    }

    modifiedName[j] = '\0';

    return modifiedName;
}



int main() {
    const char* name = "KAMIL NOWAK";
    char* modifiedName = modifyNameFormat(name);

    printf("%s\n", modifiedName);

    free(modifiedName);

    return 0;
}
