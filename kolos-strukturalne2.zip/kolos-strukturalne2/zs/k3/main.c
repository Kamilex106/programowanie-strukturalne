#include <stdio.h>

int obliczSlad(int **macierz, int wymiar) {
    int slad = 0;
    for (int i = 0; i < wymiar; i++) {
        slad += macierz[i][i];
    }
    return slad;
}

int main() {
    // Przyk�adowa macierz 3x3
    int macierz[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    int wymiar = 3;
    int *wsk_macierz[3];

    // Tworzenie wska�nik�w do wierszy macierzy
    for (int i = 0; i < wymiar; i++) {
        wsk_macierz[i] = macierz[i];
    }

    int slad = obliczSlad(wsk_macierz, wymiar);
    printf("Slad macierzy: %d\n", slad);

    return 0;
}
