#include <stdio.h>
#include <stdlib.h>

// Struktura w�z�a listy
struct Node {
    int data;
    struct Node* next;
};

// Funkcja do dodawania nowego w�z�a na pocz�tek listy
void push(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// Funkcja do wy�wietlania zawarto�ci listy
void printList(struct Node* head) {
    struct Node* current = head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

// Funkcja do usuwania �rodkowego elementu b�d� element�w z listy
void removeMiddle(struct Node** head) {
    if (*head == NULL) {
        return;
    }

    struct Node* slowPtr = *head;
    struct Node* fastPtr = *head;
    struct Node* prev = NULL;

    // Przesu� szybk� wska�nik o 2 elementy, a woln� wska�nik o 1 element
    // Dop�ki szybki wska�nik nie dotrze do ko�ca listy
    while (fastPtr != NULL && fastPtr->next != NULL) {
        fastPtr = fastPtr->next->next;
        prev = slowPtr;
        slowPtr = slowPtr->next;
    }

    // Usu� �rodkowy element b�d� elementy
    if (prev != NULL) {
        prev->next = slowPtr->next;
    } else {
        *head = slowPtr->next;
    }

    // Zwolnij pami�� po usuni�tym elemencie
    free(slowPtr);
}

// Funkcja do zwalniania pami�ci po wszystkich w�z�ach listy
void freeList(struct Node* head) {
    struct Node* current = head;
    while (current != NULL) {
        struct Node* next = current->next;
        free(current);
        current = next;
    }
}

int main() {
    struct Node* head = NULL;

    // Dodaj elementy do listy
    push(&head, 6);
    push(&head, 4);
    push(&head, 5);
    push(&head, 7);
    push(&head, 6);
    push(&head, 1);

    printf("Lista przed usunieciem srodkowego elementu/badz elementow: ");
    printList(head);

    // Usu� �rodkowy element/b�d� elementy
    removeMiddle(&head);

    printf("Lista po usunieciu srodkowego elementu/badz elementow: ");
    printList(head);

    // Zwolnij pami�� po wszystkich w�z�ach listy
    freeList(head);

    return 0;
}
