#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<stdbool.h>
struct trojkat
{
  double a,b,c;
};

double pole(struct trojkat t)
{
  int p = (t.a*t.b*t.c)/2;
  return sqrt(p*(p-t.a)*(p-t.b)*(p-t.c));
}



int main()
{
  struct trojkat t1;
  t1.a=2;
  t1.b=2;
  t1.c=2;
  printf("Pole: %f\n",pole(t1));
  printf("%d\n",sizeof(double));
  printf("%d",sizeof(struct trojkat));

    if(t1.a + t1.b > t1.c && t1.a + t1.c > t1.b && t1.b + t1.c > t1.a)
        printf("Z podanych dlugosci bokow mozna zbudowac trojkat.");
    else
        printf("Z podanych dlugosci bokow nie mozna zbudowac trojkata.");
}
