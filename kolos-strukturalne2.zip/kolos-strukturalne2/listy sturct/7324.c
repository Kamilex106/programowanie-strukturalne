#include <stdio.h>
#include <stdlib.h>

struct element {
    int i;
    struct element* next;
};

int suma_z_glowa(struct element* Lista) {
    int suma = 0;
    struct element* obecny = Lista->next; // Pomijamy g�ow� listy

    while (obecny != NULL) {
        suma += obecny->i;
        obecny = obecny->next;
    }

    return suma + 7;
}

int main() {
    // Tworzenie listy z g�ow�
    struct element* Lista = malloc(sizeof(struct element));
    Lista->next = NULL;

    // Dodawanie element�w do listy
    struct element* elem1 = malloc(sizeof(struct element));
    elem1->i = 10;
    elem1->next = NULL;
    Lista->next = elem1;

    struct element* elem2 = malloc(sizeof(struct element));
    elem2->i = 20;
    elem2->next = NULL;
    elem1->next = elem2;

    struct element* elem3 = malloc(sizeof(struct element));
    elem3->i = 30;
    elem3->next = NULL;
    elem2->next = elem3;

    // Obliczanie sumy
    int wynik = suma_z_glowa(Lista);
    printf("Suma: %d\n", wynik);

    // Zwolnienie pami�ci
    struct element* obecny = Lista;
    while (obecny != NULL) {
        struct element* temp = obecny;
        obecny = obecny->next;
        free(temp);
    }

    return 0;
}
