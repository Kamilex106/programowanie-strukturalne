#include<stdlib.h>
#include<stdio.h>

struct element * dodajnapoczatek(struct element* Lista, int a)
{
struct element *wsk=malloc(sizeof(struct element));
wsk->i=a;
wsk->next=Lista;
return wsk;
};

struct element *utworz()
{
  return NULL;
};

int main()
{
  struct element
}
