#include<stdio.h>
#include<math.h>
#include<stdbool.h>
#include<stdlib.h>
#include<wchar.h>
#include<wctype.h>
#include<ctype.h>
#include<string.h>

struct zespolone
{
  double a;
  double b;
};

void wyswietl(struct zespolone liczba)
{
  printf("%f + %f i\n",liczba.a,liczba.b);
}

void wczytaj_liczbe_zespolona(struct zespolone liczba){
scanf("%lf",&liczba.a);
scanf("%lf",&liczba.b);
}

double modul(struct zespolone liczba)
{
  return pow((liczba.a*liczba.a+liczba.b*liczba.b),0.5);
}

struct zespolone dodaj(struct zespolone liczba1, struct zespolone liczba2){
struct zespolone suma;
suma.a=liczba1.a+liczba2.a;
suma.b=liczba1.b+liczba2.b;
return suma;
};

struct zespolone iloczyn(struct zespolone liczba1, struct zespolone liczba2){
struct zespolone iloczyn;
iloczyn.a=liczba1.a*liczba2.a - liczba1.b*liczba2.b;;
iloczyn.b=liczba1.a*liczba2.b + liczba1.b*liczba2.a;;
return iloczyn;
};

struct zespolone iloraz(struct zespolone liczba1, struct zespolone liczba2) {
    struct zespolone iloraz;
    double denominator = liczba2.b * liczba2.b + liczba2.a * liczba2.a;
    iloraz.b = (liczba1.b * liczba2.b + liczba1.a * liczba2.a) / denominator;
    iloraz.a = (liczba1.a * liczba2.b - liczba1.b * liczba2.a) / denominator;
    return iloraz;
};

int main()
{
  struct zespolone X;
      X.a=2;
      X.b=7;
     wyswietl(X);
     printf("Modul liczby zespolonej wynosi %f\n", modul(X));
 struct zespolone Y;
  Y.a=4;
      Y.b=8;
  wyswietl(Y);
  struct zespolone Z;
  Z=iloraz(X,Y);
  wyswietl(Z);
}
