#include<stdio.h>
#include<math.h>
#include<stdbool.h>
#include<stdlib.h>
#include<wchar.h>
#include<wctype.h>
#include<ctype.h>
#include<string.h>

///cw 7_2_7

struct zespolone{ ///a+bi    dodawanie w liczbach zespolonych (a+bi)+(c+di)= a+c + (b+d)i czesc_rzeczywista(a+bi)=a, czesc_urojona(a+bi)=b
double a;          ///mnozenie (a+bi)*(c+di)=ac +bci + adi + bdi^2 = (ac - bd) + (bc+ad)i
double b;          ///modul(a+bi)=sqrt(a^2+b^2)
};

void wyswietl_liczbe_zespolona(struct zespolone liczba){
printf("%f + %f i\n",liczba.a,liczba.b);
}

void wczytaj_liczbe_zespolona(struct zespolone liczba){
scanf("%lf",&liczba.a);
scanf("%lf",&liczba.b);
}

double modul_liczby_zespolonej(struct zespolone liczba){
return pow((liczba.a*liczba.a+liczba.b*liczba.b),0.5);
}

struct zespolone dodaj(struct zespolone liczba1, struct zespolone liczba2){
struct zespolone suma;
suma.a=liczba1.a+liczba2.a;
suma.b=liczba1.b+liczba2.b;
return suma;
};


int main(){
      struct zespolone X;
      X.a=2;
      X.b=7;
     wyswietl_liczbe_zespolona(X);
     printf("Modul liczby zespolone wynosi %f\n", modul_liczby_zespolonej(X));
 struct zespolone Y;
  Y.a=4;
      Y.b=8;
  wyswietl_liczbe_zespolona(Y);
  struct zespolone Z;
  Z=dodaj(X,Y);
  wyswietl_liczbe_zespolona(Z);
}
