#include<stdio.h>
#include<stdlib.h>
struct element
{
  int i;
  struct element* next;
};

struct element * dodajodpowiednio(struct element* Lista, struct element* elem, int a)
{
struct element *wsk=malloc(sizeof(struct element));
wsk->i=a;
if(elem==NULL)
{
  wsk->next=Lista;
  Lista=wsk;
}
else
  {
    wsk->next=elem->next;
    elem->next=wsk;
  }
  return Lista;
}

void wyswietl_lista(struct element* Lista)
{
  struct element* obecny = Lista;
  while (obecny != NULL)
  {
    printf("%d ", obecny->i);
    obecny = obecny->next;
  }
  printf("\n");
}

int main()
{
     struct element* Lista = NULL;


    Lista = dodajodpowiednio(Lista, NULL, 10);
    Lista = dodajodpowiednio(Lista, Lista, 20);
    Lista = dodajodpowiednio(Lista, Lista->next, 30);


    wyswietl_lista(Lista);

    return 0;
}
