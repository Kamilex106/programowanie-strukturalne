#include <stdio.h>

void odwroc_kolumny(int arr[][100], int row, int col)
{
    for (int i = 0; i < col; i++)
        for (int j = 0, k = row - 1; j < k; j++, k--)
        {
            int temp = arr[j][i];
            arr[j][i] = arr[k][i];
            arr[k][i] = temp;
        }
}

void printArray(int arr[][100], int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
            printf("%d ", arr[i][j]);
        printf("\n");
    }
}

void przesun_kolumny(int arr[][100], int row, int col)
{
    for (int i = 0; i < col - 2; i++)
        for (int j = 0; j < row; j++)
        {
            int temp = arr[j][col - 1];
            arr[j][col - 1] = arr[j][i];
            arr[j][i] = temp;
        }
}




int main()
{
    int arr[][100] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int row = 3, col = 3;
    odwroc_kolumny(arr, row, col);
    printArray(arr, row, col);

    printf("\n");
    int arr2[][100] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    przesun_kolumny(arr2, row, col);
    printArray(arr2, row, col);
    return 0;

}







