#include <stdio.h>
#include <stdlib.h>


//7.3.1
struct element
{
    int i;
    struct element * next;
};


struct element *utworz() //do testowania
{
    return NULL;
};


//7.3.2
void wyczysc(struct element* Lista)
{
    struct element *wsk=Lista;
    while(Lista!=NULL)
    {
        Lista=Lista->next;
        free(wsk);
        wsk=Lista;
    }
}

void wypisz(struct element* Lista)
{
    while(Lista!=NULL)
    {
        printf("%d\n",Lista->i);
        Lista=Lista->next;
    }
    printf("\n");
}

//7.3.1




//7.3.24
int suma(struct element* Lista)
{
    int suma=0;
    while(Lista!=NULL)
    {
        suma+=Lista->i;
        Lista=Lista->next;
    }
    printf("%d",suma);
}

//7.3.20
int zeruj(struct element* Lista)
{
    while(Lista!=NULL)
    {
        Lista->i = 0;
        Lista=Lista->next;
    }
}

//dlugosc listy
int dlugosc(struct element* Lista)
{
    int elementy =0;
    while(Lista!=NULL)
    {
        elementy+=1;
        Lista=Lista->next;
    }
    printf("%d",elementy);
}



void wypisz_adresy(struct element* Lista)
{
    while(Lista!=NULL)
    {
        printf("%p\n",&Lista->i);  //lub  printf("%p\n",Lista);
        Lista=Lista->next;
    }
    printf("\n");
}

//7.3.25
int minimum(struct element* Lista)
{
    int min=Lista->i;
    while(Lista!=NULL)
    {
        if(Lista->i<min)
        {
            min=Lista->i;
        }
        Lista=Lista->next;
    }
    printf("%d",min);
}


//przeszuukaj liste w poszukiwaniu konkretnego inta
//7.3.6
struct element* znajdz(struct element * Lista, int a)
{
    while((Lista!=NULL)&&(Lista->i!=a))
    {
        Lista=Lista->next;
    }
    return Lista;
}

//7.3.7
struct element* usun(struct element * Lista, int a)
{
    struct element *wsk, *wsk2;
    if (Lista==NULL)
    {
        return Lista;
    }
    wsk=Lista;
    if(Lista->i==a)
    {
        Lista=Lista->next;
        free(wsk);
    }
    else
    {
        while((wsk->next!=NULL)&&(wsk->next->i!=a))
        {
            wsk=wsk->next;
        }
        if(wsk->next!=NULL)
        {
            wsk2=wsk->next;
            wsk->next=wsk2->next;
            free(wsk2);
        }
    return Lista;
}
}

//7.3.31

struct element* odwroc(struct element * Lista)
{
    struct element * pom1, * pom2;
    if ((Lista==NULL)||(Lista->next==NULL))
    {
        return Lista;
    }
    pom1=Lista->next;
    pom2=pom1->next;
    Lista->next=NULL;
    pom1->next=Lista;
    while(pom2!=NULL)
    {
        Lista=pom1;
        pom1=pom2;
        pom2=pom2->next;
        pom1->next=Lista;
    }
    return pom1;
};

//na kolokwium odwracanie np. ale jakies szczegolne

//7.3.30 niezrobione
struct element* doklej(struct element * Lista, struct element * Lista2)
{
    struct element * pom1, * pom2;
    if ((Lista==NULL)||(Lista->next==NULL))
    {
        return Lista;
    }
    pom1=Lista->next;
    pom2=pom1->next;
    Lista->next=NULL;
    pom1->next=Lista;
    while(pom2!=NULL)
    {
        Lista=pom1;
        pom1=pom2;
        pom2=pom2->next;
        pom1->next=Lista;
    }
    return pom1;
}
//zle^

//7.3.32
struct element* konkatynacja_na_przemian(struct element * Lista1, struct element * Lista2)
{
    struct element* wsk1=Lista1;
    struct element* wsk2=Lista2;
    struct element* pom;
    struct element* pom2;
    while(wsk2->next!=NULL)
    {
        pom=wsk1->next;

        wsk1->next=wsk2;
        pom2=wsk2->next;
        wsk2->next=pom1;

    }

    //na kolokwium cos podobnego do 7.3.32 moze byc
}











// 7.3.3
struct element * dodajnapoczatek(struct element* Lista, int a)
{
    struct element *wsk=malloc(sizeof(struct element));
    wsk->i=a;  //-> odwolanie z elementu do wspolrzednej (podobnie jak wczesniej . tylko ze w adresie) //wyluskanie elementu i kropka (inaczej * wyluskac element + pozniej .)
    wsk->next=Lista;
    return wsk;
};




// 7.3.4
struct element * dodajnakoniec(struct element* Lista, int a)
{
    struct element *wsk;
    if(Lista==NULL)
    {
        Lista=wsk=malloc(sizeof(struct element));
    }
    else
    {
        wsk=Lista;
        while(wsk->next!=NULL)
        {
            wsk=wsk->next;
        }
        wsk->next=malloc(sizeof(struct element));
        wsk=wsk->next;
    }

    wsk->i=a;
    wsk->next=NULL;
    return Lista;
};


//7.3.5
struct element * dodajodpowiednio(struct element* Lista,struct element* elem, int a)
{
    struct element *wsk=malloc(sizeof(struct element));
    wsk->i=a;
    if(elem=NULL)
    {
       wsk->next=Lista;
       Lista=wsk;
    }
    else
    {
        wsk->next=elem->next;

    }
    wsk->i=a;
    wsk->next=NULL;

    return Lista;
};




int main()
{
    //7.3.4
    struct element * lista=utworz();
    lista=dodajnakoniec(lista,4);
    wypisz(lista);
    lista=dodajnakoniec(lista,15);
    wypisz(lista);
    lista=dodajnakoniec(lista,3);
    wypisz(lista);
    lista=dodajnakoniec(lista,-7);
    wypisz(lista);
    lista=dodajnakoniec(lista,9);
    wypisz(lista);
    lista=dodajnakoniec(lista,-2);
    wypisz(lista);
    //7.3.3
    lista=dodajnapoczatek(lista,6);
    wypisz(lista);


    suma(lista);

    zeruj(lista);
    wypisz(lista);
    dlugosc(lista);
    wypisz_adresy(lista);
    minimum(lista);

    znajdz(lista,4);
    return 0;
}
