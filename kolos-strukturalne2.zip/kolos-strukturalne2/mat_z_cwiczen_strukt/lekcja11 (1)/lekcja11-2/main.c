#include <stdio.h>
#include <stdlib.h>



struct zespolone
{
    double a;
    double b;
};


void wyswietl_liczbe_zespolona(struct zespolone liczba)
{
    printf("%f + %f i\n", liczba.a,liczba.b);
}



void wczytaj_liczbe_zespolona(struct zespolone liczba)
{
    scanf("%1f",&liczba.a);
    scanf("%1f",&liczba.b);
}


double modul_liczby_zespolonej(struct zespolone liczba)
{
    return pow((liczba.a*liczba.a+liczba.b*liczba.b),0.5);

}

struct zespolone dodaj (struct zespolone liczba1,struct zespolone liczba2)
{
    struct zespolone suma;
    suma.a=liczba1.a+liczba2.a;
    suma.b=liczba1.b+liczba2.b;
    return suma;
};

struct zespolone iloczyn (struct zespolone liczba1,struct zespolone liczba2)
{
    struct zespolone iloczyn;
    iloczyn.a = liczba1.a * liczba2.a - liczba1.b * liczba2.b;
    iloczyn.b = liczba1.a * liczba2.b + liczba1.b * liczba2.a;
    return iloczyn;
};


struct zespolone iloraz (struct zespolone liczba1,struct zespolone liczba2)
{
    struct zespolone iloraz;
    iloraz.a = (liczba1.a * liczba2.a) - liczba1.b * liczba2.b;
    iloraz.b = (liczba1.a * liczba2.b) + liczba1.b * liczba2.a;
    return iloraz;
};

struct zespolone sprezenie (struct zespolone liczba1,struct zespolone liczba2)
{
    struct zespolone sprezenie;
    iloczyn.a = liczba1.a * liczba2.a + liczba1.b * liczba2.b;
    iloczyn.b = liczba1.a * liczba2.b - liczba1.b * liczba2.a;
    return sprezenie;

};















int main()
{
    struct zespolone X;
    X.a=2;
    X.b=7;
    wyswietl_liczbe_zespolona(X);
    printf("Modul liczby zespolonej wynosi %f\n", modul_liczby_zespolonej(X));
    struct zespolone Y;
    Y.a=4;
    Y.b=8;
    wyswietl_liczbe_zespolona(Y);
    struct zespolone Z;
    Z=iloraz(X,Y);
    wyswietl_liczbe_zespolona(Z);
    return 0;
}
