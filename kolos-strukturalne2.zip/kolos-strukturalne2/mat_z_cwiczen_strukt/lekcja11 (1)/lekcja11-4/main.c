#include <stdio.h>
#include <stdlib.h>


//7.3.1
struct element
{
    int i;
    struct element * next;
};


// 7.3.3
struct element * dodajnapoczatek(struct element* Lista, int a)
{
    struct element *wsk=malloc(sizeof(struct element));
    wsk->i=a;  //-> odwolanie z elementu do wspolrzednej (podobnie jak wczesniej . tylko ze w adresie) //wyluskanie elementu i kropka (inaczej * wyluskac element + pozniej .)
    wsk->next=Lista;
    return wsk;
};



int main()
{
    printf("Hello world!\n");
    return 0;
}
