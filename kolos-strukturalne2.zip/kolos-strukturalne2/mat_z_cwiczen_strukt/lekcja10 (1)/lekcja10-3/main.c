#include <stdio.h>
#include <stdlib.h>
//6.2.16
void wypisz(unsigned int n, unsigned int m, int t[][m]) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d\t", t[i][j]);
        }
        printf("\n");
    }
}

float wartosc_maksymalnej_sredniej(unsigned int n, unsigned int m, int t[][m]) {
    int i, j;
    int suma;
    int srednia;
    int maksimum;
    for (i = 0; i < n; i++) {
        suma = 0;
        for (j = 0; j < m; j++) {
            suma = suma + t[i][j];
        }
        if (i == 0) {
            maksimum = suma;

        }
        if (maksimum < suma) {
            maksimum = suma;

        }
    }
    return (float)(maksimum)/m;
}



int main() {
    int tablica[5][3] = {{4, 7,6}, {5, 2,9}, {5, 20, 9}, {5, 12, 9}, {15, 2, 9}};
    wypisz(5, 3, tablica);
    printf("%f", wartosc_maksymalnej_sredniej(5, 3, tablica));
    return 0;
}

//dla tablic tablic pd
