#include <stdio.h>
#include <stdlib.h>

//5.2.7

int male_na_duze(char* napis)
{
    int i;
    for(i=0;napis[i]!=0;i++)
    {
        if(napis[i]>=48 && napis[i] <=57)
        {
            napis[i]=napis[i]-32;
        }
    }

}


int main()
{
    char znaki[50] = "ala MA KOTA duze, napisanego o 5kg wagi!";
    printf(znaki);
    male_na_duze(znaki);
    printf("\n");
    printf(znaki);

}
