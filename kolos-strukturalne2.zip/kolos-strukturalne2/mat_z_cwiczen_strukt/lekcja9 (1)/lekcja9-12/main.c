#include <stdio.h>
#include <stdlib.h>



//6.2.7

int** alokuj_trojkatna(unsigned int n, unsigned int m)
{
    int **t = malloc(n*sizeof(int*));
    int i;
    for(i=0;i<n;i++)
    {
        t[i]=malloc((i+1)*sizeof(int));      //(n-i) dla gornej trojkatnej
    }
    return t;
}


//pierscenna
int** alokuj_pierscienna(unsigned int n, unsigned int m)
{
    int **t = malloc(n*sizeof(int*));
    int i;
    for(i=0;i<n;i++)
    {
        if (i == 0 || i== 1)
        {

        }
        t[i]=malloc(()*sizeof(int));
    }
    return t;
}


void wypisz_pierscienna(int **t,unsigned int n, unsigned int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            printf("%d\t",t[i][j]);
        }
        printf("\n");
    }
}





int main()
{
    printf("Hello world!\n");
    return 0;
}
