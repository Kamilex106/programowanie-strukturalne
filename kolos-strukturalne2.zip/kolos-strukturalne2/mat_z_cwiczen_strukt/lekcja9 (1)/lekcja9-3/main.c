
//5.2.7

#include <stdio.h>
#include <stdlib.h>

void dodawanie(char* napis, char* napis2)
{
    int i, j = 0;
    for(i = 0; napis[i] != '\0'; i++)
    {
        if(napis[i] >= '0' && napis[i] <= '8')
        {
            napis2[j++] = napis[i] + 1;
        }
        else if(napis[i] == '9')
        {
            napis2[j++] = '1';
            napis2[j++] = '0';
        }
        else
        {
            napis2[j++] = napis[i];
        }
    }
    napis2[j] = '\0';
}




int main()
{
    char znaki[50] = "ala ma 8969 kotow 299 braci i 9 siostr";
    char znaki2[55];
    printf(znaki);
    dodawanie(znaki,znaki2);
    printf("\n");
    printf(znaki2);
}
