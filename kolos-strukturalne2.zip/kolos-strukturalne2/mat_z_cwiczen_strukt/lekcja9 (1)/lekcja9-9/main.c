#include <stdio.h>
#include <stdlib.h>
#include <string>


//5.2.22

char* sklejnapisy(char* napis1, char* napis 2, char *napis3)
{
    char* wynik = malloc((strlen(napis1)+strlen(napis2)+strlen(napis3)+1)*sizeof())
    strcpy(wynik,napis1);
    strcat(wynik,napis2);
    strcpy(wynik,napis3);
}



int main()
{
    char* napis = "arbuz";
    char* napisb = "baobab";
    char* napisc = "czekolada";
    char* napiswynik;
    napiswynik=sklejnapisy

}
