#include <stdio.h>
#include <stdlib.h>

bool porownaj(char* napis1, char* na)








void wytnij2(char* napis1, char* napis2)
{
    int i,dl;
    for (dl=0;napis2(dl)!=0;dl++)
    {
        for (i=0;i+m<j;i++)
        {
            napis[n+1]=napis[m+1+1];
        }
    }
    else if((n<j)&&(j+1<=m))
    {
        napis[n]=0;
    }
}



int main()
{
    printf("Hello world!\n");
    return 0;
}



//void wytnij2(char* napis1, char* napis2)
{
    int i,dl;
    for (dl=0;napis2[dl]!=0;dl++) {}
        for (i=0;napis1[i]!=0;i+=)
        {

        if (porownaj(napis1,napis2,i))
        {
            wytnij(napis1,i,i+dl-1);
            return;
        }

        }
    }



