#include <stdio.h>
#include <stdlib.h>


char* dlugosc3(char *napis)
{
    char* wynik=malloc(100*sizeof(char));
    int i=0;
    int j=0;
    int pom=0;
     while(napis[i]!=0)
     {
         if (napis[i]!=32)
         {
             wynik[j]=napis[i];

             j++;
         }
         i++;

     }
     wynik[j]=0;
     return wynik;

}


char* dlugosc3zamiana(char *napis)
{
    char* wynik=malloc(100*sizeof(char));
    int i=0;

    int pom=0;
     while(napis[i]!=0)
     {
         if (napis[i]!=32)
         {
             wynik[i]=napis[i];
         }
         else
         {
             wynik[i]=95;
         }
         i++;

     }
     wynik[i]=0;
     return wynik;

}

void dlugosc3zamiana_2(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         if (napis[i]==32)
         {
             napis[i]=95;
         }
         i++;
     }
}







int dlugosc(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         i++;
     }
     return i;
}


int dlugosc_bez_spacji(char *napis)
{
    int i=0;
    int pom=0;
     while(napis[i]!=0)
     {
         if (napis[i]!=32)
         {
             pom++;
         }
         i++;
     }
     return pom;
}

int ile_duzych_liter(char *napis)
{
    {
    int i=0;
     while(napis[i]!=0)
     {
         if ( i >= 65 && i <= 90)
         {
             i++;
         }

     }
     return i;
}
}





int main()
{
    //printf(dlugosc3zamiana("programowanie strukturalne to bardzo przyjemny przedmiot"));
    //przed kolokw pocwicz usuwanie np. spacji itp. (usunac spacje, a wstawic podkreslniki
    //printf("%d\n",ile_duzych_liter("Olsztyn"));
    //char* napis = "\nHello world";
    //printf("%d\n",dlugosc(napis));
    //printf("%d\n",dlugosc3(napis));
    char* argument = malloc(100*sizeof(char));
    argument= "programowanie strukturalne to bardzo przyjemny przedmiot";
    printf(argument);
    printf("\n");
    dlugosc3zamiana_2(argument);
    printf(argument);
    return 0;
}
