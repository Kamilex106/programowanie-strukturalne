#include <stdio.h>
#include <stdlib.h>

int dlugosc(char *napis)
{
    int i=0;
     while(napis[i]!=0)
     {
         i++;
     }
     return i;
}


void przepisz(char*napis1,char*napis2)
{
    int i;
    for(i=0;i<dlugosc(napis1);i++)
    {
        napis2[i]=napis1[i];
    }
    napis2[dlugosc(napis1)]=0;
}void wypisz(char *napis)
{
    printf("%s\n",napis);
}




int main()
{
    char* pierwszy = "arbuz";
    char drugi[20] = "arbiter";
    wypisz(pierwszy);
    wypisz(drugi);
    printf(pierwszy);
    printf("\n");
    printf(drugi);
    printf("\n");
    przepisz(pierwszy,drugi);
    wypisz(pierwszy);
    printf("\n");
    wypisz(drugi);
    ///

    char* piaty= "student";
    char* szosty=malloc(20*sizeof(char)); //alokacja pamieci na szostego
    wypisz(piaty);
    przepisz(piaty,szosty);
    wypisz(piaty);
    wypisz(szosty);
    return 0;
}


