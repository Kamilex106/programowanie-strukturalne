#include <stdio.h>
#include <stdlib.h>


int main()
{
    printf("%d\n", sizeof(char));
    printf("%d\n",'Z');
    printf("%c\n",120);
    for(int i=0;i<127;i++)
    {
        printf("%c\n",i);
    }

    return 0;
}
