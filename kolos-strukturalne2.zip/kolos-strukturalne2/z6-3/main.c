#include <stdio.h>
#include <stdlib.h>

// Definicja struktury w�z�a listy
typedef struct node {
  int data; // Dane przechowywane w w�le
  struct node *next; // Wska�nik na nast�pny w�ze�
} node;

// Funkcja tworz�ca nowy w�ze� z dan� warto�ci� i zwracaj�ca wska�nik na niego
node *create_node(int value) {
  node *new_node = (node *)malloc(sizeof(node)); // Przydzielenie pami�ci dla nowego w�z�a
  new_node->data = value; // Przypisanie warto�ci do pola danych
  new_node->next = NULL; // Ustawienie wska�nika na nast�pny w�ze� na NULL
  return new_node; // Zwr�cenie wska�nika na nowy w�ze�
}

// Funkcja dodaj�ca nowy w�ze� na pocz�tek listy i zwracaj�ca wska�nik na now� g�ow� listy
node *prepend(node *head, int value) {
  node *new_node = create_node(value); // Utworzenie nowego w�z�a z dan� warto�ci�
  new_node->next = head; // Ustawienie wska�nika na nast�pny w�ze� na obecn� g�ow� listy
  return new_node; // Zwr�cenie wska�nika na now� g�ow� listy
}

// Funkcja usuwaj�ca �rodkowy element lub elementy z listy i zwracaj�ca wska�nik na now� g�ow� listy
node *remove_middle(node *head) {
  if (head == NULL) { // Je�li lista jest pusta, nic nie r�b i zwr�� NULL
    return NULL;
  }
  if (head->next == NULL) { // Je�li lista ma tylko jeden element, zwolnij pami�� i zwr�� NULL
    free(head);
    return NULL;
  }
  node *slow = head; // Wska�nik poruszaj�cy si� o jeden w�ze� na raz
  node *fast = head; // Wska�nik poruszaj�cy si� o dwa w�z�y na raz
  node *prev = NULL; // Wska�nik na poprzedni w�ze� od slow

  while (fast != NULL && fast->next != NULL) { // Dop�ki nie osi�gniemy ko�ca listy
    prev = slow; // Przesu� prev o jeden w�ze� do przodu
    slow = slow->next; // Przesu� slow o jeden w�ze� do przodu
    fast = fast->next->next; // Przesu� fast o dwa w�z�y do przodu
  }

  if (fast == NULL) { // Je�li liczba element�w listy jest parzysta, usu� dwa �rodkowe elementy
    prev->next = slow->next; // Przepnij wska�nik prev na nast�pny element po slow
    free(slow); // Zwolnij pami�� zajmowan� przez slow
  } else { // Je�li liczba element�w listy jest nieparzysta, usu� jeden �rodkowy element
    node *temp = slow->next; // Zapami�taj wska�nik na nast�pny element po slow
    slow->data = temp->data; // Skopiuj dane z temp do slow
    slow->next = temp->next; // Przepnij wska�nik slow na nast�pny element po temp
    free(temp); // Zwolnij pami�� zajmowan� przez temp
  }

  return head; // Zwr�� wska�nik na now� g�ow� listy
}

// Funkcja wy�wietlaj�ca zawarto�� listy od g�owy do ogona
void print_list(node *head) {
  node *current = head; // Wska�nik na obecny w�ze� listy
  while (current != NULL) { // Dop�ki nie osi�gniemy ko�ca listy
    printf("%d ", current->data); // Wy�wietl dane przechowywane w obecnym w�le
    current = current->next; // Przesu� current na nast�pny w�ze�
  }
  printf("\n"); // Wy�wietl znak nowej linii na ko�cu listy
}

// Funkcja zwalniaj�ca pami�� zajmowan� przez list� od g�owy do ogona
void free_list(node *head) {
  node *current = head; // Wska�nik na obecny w�ze� listy
  while (current != NULL) { // Dop�ki nie osi�gniemy ko�ca listy
    node *temp = current; // Zapami�taj wska�nik na obecny w�ze�
    current = current->next; // Przesu� current na nast�pny w�ze�
    free(temp); // Zwolnij pami�� zajmowan� przez temp
  }
}

// G��wna funkcja programu demonstruj�ca dzia�anie funkcji remove_middle()
int main() {
  node *head1 = NULL; // Utworzenie pustej listy

  head1 = prepend(head1, 6); // Dodanie element�w do listy: [6]
  head1 = prepend(head1, 1); // [1,6]
  head1 = prepend(head1, 9); // [9,1,6]
  head1 = prepend(head1, 8); // [8,9,1,6]
  head1 = prepend(head1, 5); // [5,8,9,1,6]

  printf("Lista przed usunieciem srodkowego elementu: ");
  print_list(head1); // Wy�wietlenie zawarto�ci listy

  head1 = remove_middle(head1); // Usuni�cie �rodkowego elementu z listy

  printf("Lista po usunieciu srodkowego elementu: ");
  print_list(head1); // Wy�wietlenie zawarto�ci listy

  free_list(head1); // Zwolnienie pami�ci zajmowanej przez list�


  node *head2 = NULL; // Utworzenie pustej listy

head2 = prepend(head2, 9); // Dodanie element�w do listy: [9]
head2 = prepend(head2, 4); // [4,9]
head2 = prepend(head2, 5); // [5,4,9]
head2 = prepend(head2, 7); // [7,5,4,9]
head2 = prepend(head2, 6); // [6,7,5,4,9]
head2 = prepend(head2, 1); // [1,6,7,5,4,9]

printf("Lista przed usunieciem srodkowego elementu: ");
print_list(head2); // Wy�wietlenie zawarto�ci listy

head2 = remove_middle(head2); // Usuni�cie �rodkowego elementu z listy

printf("Lista po usunieciu srodkowego elementu: ");
print_list(head2); // Wy�wietlenie zawarto�ci listy

free_list(head2); // Zwolnienie pami�ci zajmowanej przez list�

}
