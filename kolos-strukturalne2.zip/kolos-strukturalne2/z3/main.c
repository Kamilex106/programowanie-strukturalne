#include <stdio.h>
#include <stdlib.h>

int** wpisz(int** tab, unsigned int n, unsigned int m) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      scanf("%i", &tab[i][j]);
    }
  }
  return tab;
}

int** aloc(unsigned int n, unsigned int m) {
  int** tab = malloc(n * sizeof(int*));
  for (int i = 0; i < n; i++) {
    tab[i] = malloc(m * sizeof(int));
  }
  return tab;
}

void wypisz(int** tab, unsigned int n, unsigned int m) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      printf("%i ", tab[i][j]);
    }
    printf("\n");
  }
}

//zad3 a
int slad_mac(int** tab, unsigned int n) {
  int suma = 0;
  for (int i = 0; i < n; i++) {
    suma += tab[i][i];
  }
  return suma;
}

//zad3 b
int s_parzystych(int** tab, unsigned int n, unsigned int m) {
  int suma = 0;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      if (i == 0 && j == 0) {
        suma += tab[i][j];
      } else if (i == n - 1 && j == 0) {
        suma += tab[i][j];
      } else if (i == 0 && j == m - 1) {
        suma += tab[i][j];
      } else if (i == n - 1 && j == m - 1) {
        suma += tab[i][j];
      } else {
      }
    }
  }
  return suma;
}

int main() {
  int** tab = aloc(3, 3);
  tab = wpisz(tab, 3, 3);
  printf("\n");
  wypisz(tab, 3, 3);


  int slad = slad_mac(tab, 3);
  printf("Slad macierzy: %d\n", slad);


  int sumaParzystych = s_parzystych(tab, 3, 3);
  printf("Suma elementow parzystych na brzegach: %d\n", sumaParzystych);


  for (int i = 0; i < 2; i++) {
    free(tab[i]);
  }
  free(tab);

  return 0;
}
