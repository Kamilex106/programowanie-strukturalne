#include<stdio.h>
#include<wchar.h>

void maleduze(char* napis){
int i;
for(i=0;napis[i]!=0;i++)
{
    napis[i]=towupper(napis[i]);
}
}

int main(){
char napis[80]="do zmiany, TROCHE DUZYCH, symbole arytmetyczne 2+2=4";
printf(napis);
printf("\n");
maleduze(napis);
printf(napis);
}
