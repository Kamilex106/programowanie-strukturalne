#include<stdio.h>
#include<stdlib.h>

void male_na_duze(char* napis)
{
  int i;
  for(i=0;napis[i]!=0;i++)
  {
    if(napis[i]>=97&&napis[i]<=122)
    {
      napis[i]=napis[i]-32;
    }
  }
}

int main()
{
  char znaki[50]="ala ma KOTA duze, napisanego o 5kg wagi!";
  printf(znaki);
  male_na_duze(znaki);
  printf("\n");
  printf(znaki);
}
