#include<stdio.h>
#include<stdlib.h>

char* dlugosc(char *napis)
{
  char* wynik=malloc(100*sizeof(char));
  int i=0;
  while(napis[i]!=0)
  {
    if(napis[i]!=32)
    {
      wynik[i]=napis[i];
    }
    else
    {
      wynik[i]=95;
    }
    i++;
  }
  wynik[i]=0;
  return wynik;
}

int main()
{
  printf(dlugosc("all we have to do to follow the damn train CJ"));

}
