#include<stdio.h>
#include<stdlib.h>

char* godzina(int godz, int min, int sek){
char* wynik=malloc(9*sizeof(char));
sprintf(wynik,"%02d:%02d:%02d",godz,min,sek);
return wynik;
}

int main(){
int godziny=23;
int minuty=59;
int sekundy=59;
printf(godzina(godziny,minuty,sekundy));
}
