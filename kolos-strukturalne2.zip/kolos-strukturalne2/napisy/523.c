#include<stdio.h>
#include<stdlib.h>

int dlugosc(char *napis)
{
  int i=0;
  while(napis[i]!=0)
  {
    i++;
  }
  return i;
}

int porownajnapisy(char *napis,char *napis2)
{
  int i;
  int d11=dlugosc(napis);
  int d12=dlugosc(napis2);
  if(d11=d12)
  {
    for(i=0;i<=d12-1;i++)
    {
      if(napis[i]!=napis2[i])
      {
        return 0;
      }
    }
  }

}

int main()
{
  printf("%d\n",porownajnapisy("pierwszy napis","drugi napis"));

}
