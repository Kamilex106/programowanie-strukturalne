#include<stdio.h>
//potem w zdj�ciach zedytuj
int porownaj(char *napis,char *napis2){
    int i,j;
    for(i=0;napis[i] || napis2[i];i++){
        if(napis[i]==0 && napis2[i]!=0){
            return 0;
        }
        if(napis[i]!=0 && napis2[i]==0){
            return 1;
        }
        if(napis[i]==0 && napis2[i]==0){
            for(j=0;napis[j];j++){
                if(napis[j]<napis2[j] == 0){
                    return 0;
                }
            }
        }
    }
    return 1;
}

int main(){
    printf("%d\n",porownaj("arbuz","arbiter"));
    printf("%d\n",porownaj("baba","alibaba"));
    printf("%d\n",porownaj("hulajdusza","hulajnoga"));
}
