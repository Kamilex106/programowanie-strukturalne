#include<stdlib.h>

///cw 6_2_2
int(* alokuj2(unsigned int n, unsigned int m))[]{
return malloc(n*sizeof(int[m]));
}

int main(){
}
