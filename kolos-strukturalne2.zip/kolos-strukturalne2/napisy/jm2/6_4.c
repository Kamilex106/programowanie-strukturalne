#include<stdlib.h>

///cw 6_2_4
void zwolnij2(unsigned int n, int t[][n]){
free(t);
}


int main(){
}
