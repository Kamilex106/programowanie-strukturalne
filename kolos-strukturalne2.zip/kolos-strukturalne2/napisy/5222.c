#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char* sklejnapisy(char* napis1, char* napis2, char* napis3)
{
  char* wynik=malloc((strlen(napis1)+strlen(napis2)+strlen(napis3)+1)*sizeof(char));
strcpy(wynik,napis1);
strcat(wynik,napis3);
return wynik;
}


int main(){
    char* napisa="arbuz";
char* napisb="baobab";
char* napisc="czekolada";
char* napiswynik;
napiswynik=sklejnapisy(napisa,napisb,napisc);
printf(napiswynik);
}
