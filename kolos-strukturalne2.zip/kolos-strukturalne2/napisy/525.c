#include<stdio.h>
#include<stdlib.h>

int dlugosc(char *napis)
{
  int i=0;
  while(napis[i]!=0)
  {
    i++;
  }
  return i;
}

void przepisz(char*napis, char*napis2){
    int i;
    for(i=0;i<dlugosc(napis);i++)
    {
        napis2[i]=napis[i];
    }
    napis2[dlugosc(napis)]=0;
}

void wypisz(char * napis){
printf("%s\n",napis);
}

//int porownaj(char *napis,char *napis2){
//    int i,j;
//    for(i=0;napis[i] || napis2[i];i++){
//        if(napis[i]==0 && napis2[i]!=0){
//            return 0;
//        }
//        if(napis[i]!=0 && napis2[i]==0){
//            return 1;
//        }
//        if(napis[i]==0 && napis2[i]==0){
//            for(j=0;napis[j];j++){
//                if(napis[j]<napis2[j] == 0){
//                    return 0;
//                }
//            }
//        }
//    }
//    return 1;
//}

int main(){

char* pierwszy="arbuz";
char drugi[20]="arbiter";
wypisz(pierwszy);
wypisz(drugi);

printf(pierwszy);
printf("\n");
printf(drugi);
printf("\n");
przepisz(pierwszy,drugi);
wypisz(pierwszy);
wypisz(drugi);

char* piaty="student";
char* szosty=malloc(20*sizeof(char));
wypisz(piaty);
przepisz(piaty,szosty);
wypisz(piaty);
wypisz(szosty);
}
