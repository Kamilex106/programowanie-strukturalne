#include<stdio.h>
#include<stdlib.h>

int dlugosc(char *napis)
{
  int i=0;
  int pom=0;
  while(napis[i]!=0)
  {
    if(napis[i]!=32)
    {
      pom++;
    }
    i++;
  }
  return pom;
}

int main()
{
  printf("%d\n",dlugosc("a b c d e f"));

}
