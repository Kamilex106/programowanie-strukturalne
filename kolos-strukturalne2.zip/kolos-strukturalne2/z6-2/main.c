#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *next;
} node;

node *removeMiddle(node *head) {
    if (head == NULL || head->next == NULL) {
        return head;
    }

    node *slow = head;
    node *fast = head;
    node *prev = NULL;

    while (fast != NULL && fast->next != NULL) {
        prev = slow;
        slow = slow->next;
        fast = fast->next->next;
    }

    if (fast == NULL) {
        prev->next = slow->next->next;
        free(slow->next);
        free(slow);
    } else {
        prev->next = slow->next;
        free(slow);
    }

    return head;
}

void printList(node *head) {
    while (head != NULL) {
        printf("%d ", head->data);
        head = head->next;
    }
}

int main() {
    node *head = malloc(sizeof(node));
    head->data = 5;
    head->next = malloc(sizeof(node));
    head->next->data = 8;
    head->next->next = malloc(sizeof(node));
    head->next->next->data = 9;
    head->next->next->next = malloc(sizeof(node));
    head->next->next->next->data = 1;
    head->next->next->next->next = malloc(sizeof(node));
    head->next->next->next->next->data = 6;
    head->next->next->next->next->next = NULL;

    printList(head);
    printf("\n");

    head = removeMiddle(head);

    printList(head);
}
