#include<stdio.h>
#include<stdlib.h>


void zamien(int **t1, int **t2, unsigned int n, unsigned int m){
    int i,j,pom;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
    pom=t2[i][j];
   t2[i][j]=t1[i][j];
   t1[i][j]=pom;
}
}
}


int** alokuj(unsigned int n, unsigned int m){
int **t=malloc(n*sizeof(int*));
int i;
for(i=0;i<n;i++)
{
    t[i]=malloc(m*sizeof(int));
}
return t;
}


void wczytaj(int** t, unsigned int n,unsigned int m){
int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
       scanf("%d",&t[i][j]);
    }
}
}

void wypisz(int **t, unsigned int n, unsigned int m){
    int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
    printf("%d\t",t[i][j]);
}
printf("\n");
}
}

int main(){
    int **t=alokuj(2,3);
    int **v=alokuj(2,3);
    wczytaj(t,2,3);
wypisz(t,2,3);
  wczytaj(v,2,3);
  wypisz(v,2,3);
zamien(t,v,2,3);
wypisz(t,2,3);
wypisz(v,2,3);
};
