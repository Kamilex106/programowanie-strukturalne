#include<stdio.h>


int sumuj(unsigned int n,unsigned int m, int t[][m]){
int i,j;
int suma=0;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
       suma=suma+t[i][j];
    }
}
return suma;
}

void wypisz(unsigned int n,unsigned int m, int t[][m]){
int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
       printf("%d\t",t[i][j]);
    }
    printf("\n");
}
}

int main(){
    int t[2][3]={{4,7,6},{5,2,9}};
wypisz(2,3,t);
printf("%d",sumuj(2,3,t));
}

