#include<stdio.h>

double indeks_maksymalny_sredniej(unsigned int n,unsigned int m, int t[][m]){
int i,j;
int suma;
int maksimum;
int indeks;
for(i=0;i<n;i++)
{
suma=0;
    for(j=0;j<m;j++)
{
       suma=suma+t[i][j];
    }
if(i==0)
{
  maksimum=suma;
}
if(maksimum<suma)
{
  maksimum=suma;
}
}
return  ((double)(maksimum)/m);
}


void wypisz(unsigned int n,unsigned int m, int t[][m]){
int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
{
       printf("%d\t",t[i][j]);
    }
    printf("\n");
}
}

int main(){
int t[5][3]={{4,7,6},{5,2,9},{5,20,9},{5,12,9},{15,2,9}};
wypisz(5,3,t);
printf("%f",indeks_maksymalny_sredniej(5,3,t));
}
