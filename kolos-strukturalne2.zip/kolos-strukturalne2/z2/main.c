#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int dlugosc(char* napis) {
    int dl = 0;
    while (napis[dl] != '\0') {
        dl++;
    }
    return dl;
}

char * zmod_napis(char* napis){
    int dl = dlugosc(napis);
    char* nowy = malloc((2*dl + 1) * sizeof(char));
    int j = 0;
    for (int i = 0; i < dl; i++) {
        nowy[j] = napis[i];
        j++;
        if (i < dl - 1 && ((napis[i] - napis[i + 1]) == 1 || (napis[i] - napis[i + 1]) == -1)) {
            nowy[j] = 'W';
            j++;
        }
    }
    nowy[j] = '\0';
    return nowy;
}

int main() {
    char napis[] = "baobab";
    char* wynik = zmod_napis(napis);
    printf("%s\n", wynik);
    return 0;
}
