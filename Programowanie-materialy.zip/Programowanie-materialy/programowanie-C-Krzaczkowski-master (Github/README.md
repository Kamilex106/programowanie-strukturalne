Programowanie w języku C
===============

[zbiór zadań](http://informatyka.umcs.lublin.pl/files/Skrypty/krzaczkowski_pop.pdf)
[zbiór zadań 2](http://www.fuw.edu.pl/~polbrat/zadania.pdf)
