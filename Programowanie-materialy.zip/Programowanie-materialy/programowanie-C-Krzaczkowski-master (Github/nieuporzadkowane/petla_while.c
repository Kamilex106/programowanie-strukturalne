#include <stdio.h>

int main()
{
	int i = 0;

	while ( i < 10 )
	{
		printf ( "%i \n", i );
		i += 1;
	}
	return 0;
}

