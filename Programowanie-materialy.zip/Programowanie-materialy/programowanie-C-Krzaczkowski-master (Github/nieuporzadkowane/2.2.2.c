/*
	2.2.2 (r) Napisz program, który wczytuje ze standardowego wejścia nie-
	ujemną liczbę całkowitą n i wypisuje na standardowym wyjściu liczbę
	n!. W programie użyj samodzielnie zaimplementowanej funkcji liczącej
	wartość silni.
*/


#include <stdio.h>

int main()
{
	return 0;
}

