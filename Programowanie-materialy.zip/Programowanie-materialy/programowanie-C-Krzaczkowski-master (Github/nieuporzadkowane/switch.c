#include <stdio.h>

int main()
{
	int n;
	scanf ( "%i", &n );

	switch ( n )
	{
		case 1:
			printf ( "jeden \n" );


		case 2:
			printf ( "dwa \n" );


		default:
			printf ( "x \n" );
	}


	return 0;
}

