#include <stdio.h>

int main()
{
	for ( int i = 5 ; i < 16 ; i += 1 )
	{
		printf ( "%i \n", i );
	}
	return 0;
}

