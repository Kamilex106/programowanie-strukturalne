#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    cout << "Napis zawierający różne dziwne znaczniki // \\\\ $ & %" << endl;

    return 0;
}
