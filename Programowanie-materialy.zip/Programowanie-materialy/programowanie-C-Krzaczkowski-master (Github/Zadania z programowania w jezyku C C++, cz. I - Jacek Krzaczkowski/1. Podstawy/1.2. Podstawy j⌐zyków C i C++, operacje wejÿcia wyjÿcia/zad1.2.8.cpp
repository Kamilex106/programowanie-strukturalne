#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    int x;
    int y;
    int z;

    cin >> x >> y >> z;
    
    cout << (x + y + z) / 3.0 << endl; 
    
    return 0;
}
