#include <stdio.h>
#include <math.h>

int main()
{
    float fX;
    scanf( "%f", & fX );
    printf( "%e \n", fX );
    
    return 0;
}
