#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    int x;
    int y;
    int z;
    
    cin >> x >> y >> z;
    
    cout << x << endl << y << endl << z << endl;
    return 0;
}
