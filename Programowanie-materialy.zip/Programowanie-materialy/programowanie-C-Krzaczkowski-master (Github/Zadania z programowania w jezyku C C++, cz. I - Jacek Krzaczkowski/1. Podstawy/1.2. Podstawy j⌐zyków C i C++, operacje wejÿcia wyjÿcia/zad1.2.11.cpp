#include <stdio.h>
#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    double x;
    
    cin >> x;
    
    cout << setprecision(2) << x << endl;
    
    return 0;
}
