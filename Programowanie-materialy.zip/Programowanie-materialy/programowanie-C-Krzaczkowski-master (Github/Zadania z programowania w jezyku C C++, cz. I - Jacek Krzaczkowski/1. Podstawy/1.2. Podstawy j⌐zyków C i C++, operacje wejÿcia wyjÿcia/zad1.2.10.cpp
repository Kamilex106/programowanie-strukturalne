#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    double x;
    
    cin >> x;
    
    if(x < 0)
    {
        cout << -x << endl; 
    }
    else
    {
        cout << x << endl; 
    }

    return 0;
}
