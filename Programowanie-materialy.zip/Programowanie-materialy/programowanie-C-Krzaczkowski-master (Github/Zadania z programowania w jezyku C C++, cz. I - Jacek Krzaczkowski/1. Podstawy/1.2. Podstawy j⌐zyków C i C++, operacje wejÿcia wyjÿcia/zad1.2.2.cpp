#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    cout << "Bardzo" << endl;
    cout << "długi" << endl;
    cout << "napis" << endl;
    
    return 0;

}
