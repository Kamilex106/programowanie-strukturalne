#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    int x;
    cin >> x;
    
    cout << x << endl;

    return 0;
}
