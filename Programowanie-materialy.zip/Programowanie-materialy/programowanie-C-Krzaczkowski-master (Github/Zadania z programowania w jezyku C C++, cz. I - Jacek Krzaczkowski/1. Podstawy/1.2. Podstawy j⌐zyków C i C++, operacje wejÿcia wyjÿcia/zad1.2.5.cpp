#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    double x;
    cin >> x;
    
    cout << x << endl;

    return 0;
}
