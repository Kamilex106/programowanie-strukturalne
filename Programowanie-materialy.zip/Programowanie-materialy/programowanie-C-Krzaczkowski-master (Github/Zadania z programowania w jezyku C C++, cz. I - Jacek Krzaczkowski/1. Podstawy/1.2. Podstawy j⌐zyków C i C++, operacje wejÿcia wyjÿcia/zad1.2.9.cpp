#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    double x;
    
    cin >> x;

    cout << sqrt(x) << endl;

    return 0;
}
