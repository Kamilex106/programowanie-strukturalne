#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n;
    
    cin >> n;
    
    if(n < 0)
    {
        cout << -n << endl; 
    }
    else
    {
        cout << n << endl; 
    } 
    
    return 0;
}
