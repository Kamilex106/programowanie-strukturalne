#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int a;
    int b;
    
    cin >> a >> b;
    
    if (a > b)
    {
        cout << a << endl;
    }
    else
    {
        cout << b << endl;
    }

    return 0;
}
