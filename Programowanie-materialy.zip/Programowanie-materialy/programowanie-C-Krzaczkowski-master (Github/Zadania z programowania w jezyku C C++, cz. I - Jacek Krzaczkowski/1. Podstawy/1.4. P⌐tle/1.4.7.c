/*
	1.4.7 Napisz program, który wczytuje ze standardowego wejścia dwie liczby
	całkowite n i m (zakładamy, że n < m) i wypisuje na standardowym
	wyjściu liczbę n ∗ . . . ∗ m.
*/


#include <stdio.h>

int main()
{
	return 0;
}

