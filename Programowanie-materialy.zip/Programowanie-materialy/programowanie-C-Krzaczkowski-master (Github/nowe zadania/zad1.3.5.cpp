#include <stdio.h>
#include <iostream>
#include <math.h>

int main()
{
    int a;
    int b;
    int c;
    
    

    return 0;
}
