/*
 Zbiór zadań z programowania w języku C/C++ cz. 2
 Jacek Krzaczkowski

 Zadanie 2.4

 Zaimplementuj klasę `funkcja` posiadającą publiczne pole `x` oraz czysto wirtualną metodę `wartosc`,
 która w klasach pochodnych będzie zwracała wartość funkcji przechowywanej w obiekcie w punkcie `x`.
*/


class funkcja
{
  public:
    double x;
  
    virtual double wartosc() = 0;    
};
