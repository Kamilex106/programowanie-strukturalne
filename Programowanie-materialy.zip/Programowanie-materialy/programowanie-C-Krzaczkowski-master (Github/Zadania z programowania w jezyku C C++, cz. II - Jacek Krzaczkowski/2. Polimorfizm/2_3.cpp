/*
 Zbiór zadań z programowania w języku C/C++ cz. 2
 Jacek Krzaczkowski

 Zadanie 2.3

 Napisz klasę `zespolone` pochodną klasy liczba z zadania 2.2 posiadającą dodatkowo publiczne pole `im` typu `int`.
 Przeciąż w klasie zespolone metodę `modul`. Czy metodę `wiekszy` też trzeba przeciążyć?
*/

class zespolona : public liczba
{
  public:
    int im;
  
    double modul()
    {
      return sqrt(re*re + im*im);
    }
  
    // nie trzeba przeciążać metody `wieksza`
};
