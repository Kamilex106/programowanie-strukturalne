/* Zadanie 3.17

Napisz klasę finalna, po której nie można dziedziczyć.
*/

final class finalna
{

};
