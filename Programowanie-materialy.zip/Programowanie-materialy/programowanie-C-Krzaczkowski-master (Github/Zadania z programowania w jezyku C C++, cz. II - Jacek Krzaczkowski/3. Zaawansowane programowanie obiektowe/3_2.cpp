/*
Zadanie 3.2

Napisz klasę liczba zawierającą publiczne statyczne pole licz typu
int. Wartość pola licz zainicjuj wartością 0.
*/


class liczba
{
    public:
        static int licz;
};

int liczba::licz = 0;
