/*
Zadanie 3.3

Napisz klasę tablica zawierającą jako pole 5-elementową statyczną ta-
blicę liczb całkowitych. Elementy tablicy zainicjuj wartościami kolejnych
liczb pierwszych począwszy od 2.
*/

class tablica
{
    static int tab[5];
};

int tablica::tab[] = {2, 3, 5, 7, 11};
