/*
Zadanie 3.1

Napisz klasę stale zawierającą publiczne stałe statyczne
pola pi i e.
*/


class statyczne
{
    public:
        static const double pi;
        static const double e;

};

const double statyczne::pi = 3.14; 
const double statyczne::e = 2.72;
