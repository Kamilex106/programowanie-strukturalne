#include <iostream>
using namespace std;

class UkrytaLiczba
{
	private:
		double liczba;

	public:
		void zeruj ()
		{
			liczba = 0;
		}
};

int main ()
{

	return 0;
}
