#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x =5;
    printf("%p\n", &x);
    return 0;
}
