#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,d;
    a=8;
    return 0;
}
