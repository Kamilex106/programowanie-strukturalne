#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tab[4] = {1,-3,4,5};
    const int tab2[4] = {1,-3,4,5};
    return 0;
}
