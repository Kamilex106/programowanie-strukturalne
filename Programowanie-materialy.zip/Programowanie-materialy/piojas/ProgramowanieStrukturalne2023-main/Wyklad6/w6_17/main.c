#include <stdio.h>
int main(void)
{
    int tab[4]={1,-3,4,2};
    int *wsk1, *wsk2;
    wsk1=tab;
    wsk2=&tab[3];
}
