#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tab[4];
    char tab2[3];
    float tabf[5];
    return 0;
}
