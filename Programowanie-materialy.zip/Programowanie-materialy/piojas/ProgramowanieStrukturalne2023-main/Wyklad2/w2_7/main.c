#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a=1.1;
    float b=3.3;
    printf("%d",b==3*a);
    return 0;
}
