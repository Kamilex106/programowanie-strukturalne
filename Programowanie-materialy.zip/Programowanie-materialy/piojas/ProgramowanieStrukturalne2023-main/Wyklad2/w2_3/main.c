#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%i",&a);
    printf("%i", a);
    return 0;
}
