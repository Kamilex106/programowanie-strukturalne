#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("%d",__STDC_VERSION__);
    return 0;
}
