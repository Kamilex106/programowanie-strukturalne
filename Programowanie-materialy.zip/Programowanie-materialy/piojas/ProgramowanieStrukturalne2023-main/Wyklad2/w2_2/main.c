#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    a=8;
    printf("asss\n");
    printf("Liczba:%d\n", a);
    return 0;
}
