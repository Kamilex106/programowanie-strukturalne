#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 5;
    a= -2;
    a=7;
    return 0;
}
