#include <stdio.h>
#include <stdlib.h>

int foo(int a)
{
    if( a>0)
        return a;
    return -a;
}

int main()
{
    printf("Hello world!\n");
    return 0;
}
