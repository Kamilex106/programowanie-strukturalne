//wskazniki podwojenie

#include <stdio.h>
#include <stdlib.h>

int podwoj(int* x)
{
    *x=2*(*x);
    return *x;
}
int main()
{
    int a=7;
    printf("%d\n",a);
    printf("%d\n",podwoj(&a));
    printf("%d",a);
    return 0;
}

