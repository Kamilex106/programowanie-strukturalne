//porownanie

#include <stdio.h>
int main()
{
	int a,b,c,d;
	a=1;
	b=1;
	c=1;
	d=1;
	scanf ( "%d %d %d %d", &a, &b, &c, &d );
	if (a == b && a== c && a==d)
    {
        printf ( "kareta" );
    }
    else if ((a==b && b==c) || (b==c && b==d) || (a==c && c==d) )
    {
        printf("trojka");
    }
    else if ((a==b && c==d) || (a==c && b==d) || (a==d && b==c))
    {
        printf("podwojna para");
    }
    else if (a==b || a==c || a==d || b==c || b==d || c==d)
    {
        printf("para");
    }
    else
    {
        printf("nic");
    }
}
