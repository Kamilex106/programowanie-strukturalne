//p�tla liczba i cyfra

#include <stdio.h>
#include <stdbool.h>

int main() {
    int liczba, cyfra, temp, ostatnia_cyfra;
    bool znaleziono = false;

    printf("Podaj liczbe: ");
    scanf("%d", &liczba);

    printf("Podaj cyfre: ");
    scanf("%d", &cyfra);

    temp = liczba;

    while (temp > 0) {
        ostatnia_cyfra = temp % 10;

        if (ostatnia_cyfra == cyfra) {
            znaleziono = true;
            break;
        }

        temp /= 10;
    }

    if (znaleziono) {
        printf("Cyfra %d znajduje sie w liczbie %d\n", cyfra, liczba);
    } else {
        printf("Cyfra %d nie znajduje sie w liczbie %d\n", cyfra, liczba);
    }

    return 0;
}

//kod pozycja
//#include <stdio.h>
//#include <stdbool.h>
//
//int main() {
//    int liczba, cyfra, temp, ostatnia_cyfra, pozycja = 1;
//    bool znaleziono = false;
//
//    printf("Podaj liczbe: ");
//    scanf("%d", &liczba);
//
//    printf("Podaj cyfre: ");
//    scanf("%d", &cyfra);
//
//    temp = liczba;
//
//    printf("Cyfra %d wystepuje na miejscach: ", cyfra);
//    while (temp > 0) {
//        ostatnia_cyfra = temp % 10;
//
//        if (ostatnia_cyfra == cyfra) {
//            znaleziono = true;
//            printf("%d ", pozycja);
//        }
//
//        temp /= 10;
//        pozycja++;
//    }
//
//    if (!znaleziono) {
//        printf("Cyfra %d nie znajduje sie w liczbie %d\n", cyfra, liczba);
//    } else {
//        printf("\n");
//    }
//
//    return 0;
//}
//
