//tablice parzyste zamiana


//#include <stdio.h>
//#include <stdlib.h>
//
//void wypisz(unsigned int n,int *tab)
//{
//    int i;
//    for(i=0;i<n;i++)
//    {
//        printf("%d\t",tab[i]);
//    }
//    printf("\n");
//}
//
//void odwroc(unsigned int n, int *tab)
//{
//    int i,pom;
//    for (i=0;i<n/2;i++)
//    {
//        if (tab[i]%2==0)
//        {
//        pom=tab[i];
//        tab[i]=tab[n-1-i];
//        tab[n-1-i]=pom;
//        }
//
//    }
//}
//int main()
//{
//    int tablica2[] = {1, 2, 3, 4, 5, 6, 7,8,9,10};
//    odwroc(10, tablica2);
//    wypisz(10,tablica2);
//    return 0;
//}


#include <stdio.h>
#include <stdlib.h>

void wypisz(unsigned int n, int *tab)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%d\t", tab[i]);
    }
    printf("\n");
}

void odwroc(unsigned int n, int *tab)
{
    int i, j, temp;
    i = 0;
    j = n - 1;
    while (i < j)
    {
        if (tab[i] % 2 == 0)
        {
            while (j > i && tab[j] % 2 != 0)
            {
                j--;
            }

            if (i < j)
            {
                temp = tab[i];
                tab[i] = tab[j];
                tab[j] = temp;
            }
            j--;
        }
        i++;
    }
}

int main()
{
    int tablica2[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    odwroc(10, tablica2);
    wypisz(10, tablica2);
    return 0;
}
