//tablica niepowtarzalne

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void wypisz_unikalne(unsigned int n, int *tab)
{
    int i, j;
    bool unique;
    for (i = 0; i < n; i++)
    {
        unique = true;
        for (j = 0; j < i; j++)
        {
            if (tab[i] == tab[j])
            {
                unique = false;
                break;
            }
        }
        if (unique)
        {
            printf("%d\n", tab[i]);
        }
    }
    printf("\n");
}
int main()
{
    int tablica2[] = {7, 9, 51, -208, 7, 9, 7};
    wypisz_unikalne(7, tablica2);
    return 0;
}


//
//#include <stdio.h>
//#include <stdbool.h>
//
//void wypisz(unsigned int n, int *tab)
//{
//    int i, j;
//    bool unique;
//
//    for (i = 0; i < n; i++)
//    {
//        unique = true;
//        for (j = 0; j < n; j++)
//        {
//            if (i != j && tab[i] == tab[j])
//            {
//                unique = false;
//                break;
//            }
//        }
//        if (unique)
//        {
//            printf("%d\n", tab[i]);
//        }
//    }
//    printf("\n");
//}
//
//int main()
//{
//    int tablica2[] = {7, 9, 51, -208, 7, 9, 7};
//    wypisz(7, tablica2);
//
//    return 0;
//}


