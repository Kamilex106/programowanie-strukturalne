//#include <stdio.h>
//#include <stdlib.h>
//
//
//void wypisz(unsigned int n,int *tab)
//{
//    int i;
//    for(i=0;i<n;i++)
//    {
//        printf("%d   ",tab[i]);
//    }
//    printf("\n");
//}
//
//void laczenie_przemienne(unsigned int n, int* tab1, int* tab2,int* tab3)
//{
//
//    int i;
//    for(i=0;i<2*n;i=i+2)
//    {
//        tab3[i]=tab2[i/2];
//    }
//    for(i=1;i<2*n;i=i+2)
//    {
//        tab3[i]=tab1[(i-1)/2];
//    }
//}
//
//
//
//int main()
//{
//    int tab[] = {5,4,2,7};
//    int tabb[]={8,1,9,3};
//    int tab1[8];
//    laczenie_przemienne[4,tab,tabb,tab1];
//    wypisz(8,tab1);
//
//}


#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d   ",tab[i]);
    }
    printf("\n");
}

int maksimum(unsigned int n, int* tab)
{

    int i;
    int max=tab[0];
    for(i=0;i<n;i++)
    {
        if (tab[i]>max)
        {
            max=tab[i];
        }

    }
    return max;
}




int main()
{
    int tab[] = {7,9,1,3};
    int tabb[]={5,4,2,7};
    int tab1[]={1,8,6,5};
    printf("%d",maksimum(4,tab));
}


//pd minimum
