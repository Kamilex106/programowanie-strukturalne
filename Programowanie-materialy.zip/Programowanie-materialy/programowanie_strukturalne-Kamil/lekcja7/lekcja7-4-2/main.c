
#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d   ",tab[i]);
    }
    printf("\n");
}

int maksimum_index(unsigned int n, int* tab)
{

    int i;
    int indeks=0;
    int max=tab[0];
    for(i=0;i<n;i++)
    {
        if (tab[i]>max)
        {
            max=tab[i];
            indeks=i;
        }

    }
    return indeks;
}




int main()
{
    int tab[] = {7,9,1,3};
    int tabb[]={5,4,2,7};
    int tab1[]={1,8,6,5};
    printf("%d",maksimum_index(4,tab));
}
