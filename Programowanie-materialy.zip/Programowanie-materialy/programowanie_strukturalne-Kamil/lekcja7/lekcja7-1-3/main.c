#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d   ",tab[i]);
    }
    printf("\n");
}

void zamiana(unsigned int n, int* tab1, int* tab2, int* tab3)
{

    int i;
    int temp;
    for(i=0;i<n;i++)
    {
        temp = tab2[i];
        tab2[i]=tab1[i];
        tab1[i]=tab3[i];
        tab3[i]=temp;
    }
}



int main()
{
    int tab[] = {5,4,2,7};
    int tabb[]={8,1,9,3};
    int tab1[]={3,6,2,5};

    zamiana(4,tab,tabb,tab1);
    wypisz(4,tab);
    wypisz(4,tabb);
    wypisz(4,tab1);

}
