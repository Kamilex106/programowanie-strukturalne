#include <stdio.h>
#include <stdlib.h>

int ilewody(int tab[], size_t len)
{
    int litry = 0;
    int max_left = 0, max_right = 0;
    int left = 0, right = len - 1;
    while (left <= right)
    {

        if (tab[left] < tab[right])
        {
            if (tab[left] > max_left)
            {
                max_left = tab[left];
            }
            else
            {
                litry += max_left - tab[left];
            }
            left++;
        }

        else
        {
            if (tab[right] > max_right)
            {
                max_right = tab[right];
            }
            else
            {
                litry += max_right - tab[right];
            }
            right--;
        }
    }
    return litry;
}

int main()
{
    int tab[9] = {3, 5, 2, 7, 4, 1, 0, 6, 5};
    int tab2[6] = {5,4,3,2,1,0};
    int tab3[4] = {4,2,2,5};
    int tab4[9] = {4,2,2,5,1,3,4,6,5};
    int tab5[10] = {4,6,2,4,1,5,7,1,3,2};


    size_t len = sizeof(tab) / sizeof(int);

    printf("%d\n", ilewody(tab, len));
    printf("%d\n", ilewody(tab2, 6));
    printf("%d\n", ilewody(tab3, 4));
    printf("%d\n", ilewody(tab4, 9));
    printf("%d\n", ilewody(tab5, 10));
    return 0;
}









// 1 funkcja przyjmuje tablice (rozmiar argumentem wskaznik na tablice i zwrocic ma tez wskaznik na tablice
//np podam 6 i te tablice to wynikiem ma byc inna tablica



//2 program przeliczajacy ilosc litrow wody osazdajacej sie w kratkach
