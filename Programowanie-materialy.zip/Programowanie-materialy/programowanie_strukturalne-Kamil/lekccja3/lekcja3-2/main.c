#include <stdio.h>
#include <stdlib.h>
//liczba doskonala to taka liczba ktora jest rowna sumie swoich licznikow wlasciwych
//1 2 3 -> 6
//1 2 4 7 14 -> 28
//496
//8128
//suma licznikow jest rowna im samym
//generator liczb doskonaly do i (2 miliardy)
int CzyDoskonala(int liczba)
{
    int sumaDzielnikow =1;
    for(int i=2;i<liczba;i++)
    {
        if(liczba%i=0)
            sumaDzielnikow +=1;
        if(sumaDzielnikow>liczba)
            return 0;
    }
    if (sumaDzielnikow == liczba)
        return 1;
    return 0;
int main()
{

}

    //wykorzytujac twierdzenie oulera o liczbach doskonalych zmodyfikuj ten program aby wyswitelil rowniez co najmniej 5 liczbe doskonala

}
