#include <stdio.h>
#include <stdlib.h>
//zad.3.2.9
int* rezerwuj()
{
    return malloc(sizeof(int));
}
int main()
{
    int* wsk=rezerwuj();
    printf("%p\n",wsk);
    printf("%d\n",*wsk);
    return 0;
}
