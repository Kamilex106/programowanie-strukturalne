#include <stdio.h>
#include <stdlib.h>

int mniejsza(int* x,int* y)
{
    if (*x>*y)
    {
        return y;
    }
    return x;
}
int main()
{
    int a=15;
    int b=20;
    printf("%p\n",&a);
    printf("%p\n",&b);
    printf("%p\n",mniejsza(&a,&b));
    return 0;
}
