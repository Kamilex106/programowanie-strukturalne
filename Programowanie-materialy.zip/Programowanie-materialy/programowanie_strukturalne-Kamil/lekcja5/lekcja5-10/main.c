#include <stdio.h>
#include <stdlib.h>
//zad.3.2.13
double fun(int x)
{
    return 3*x;
}
double gie(double (*f)(int x),int n)
{
    return f(n);
}
int main()
{
    int x=5;
    printf("%f",gie(&fun,x)); //moze byc bez & przed fun
//    int* wsk=rezerwuj(10);
//    printf("%p\n",wsk);
//    printf("%d\n",*wsk);
    return 0;
}
