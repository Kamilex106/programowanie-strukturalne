#include <stdio.h>
#include <stdlib.h>

int suma(const int* x,const int* y)
{
    return *x + *y;
}
int main()
{
    int a=15;
    int b=10;
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    printf("%d\n",suma(&a,&b));
    return 0;
}
