#include <stdio.h>
#include <stdlib.h>

void zamien(int* x,int* y)
{
    //int* t=malloc(sizeof(int));
    //*t=*x;
    //*x=*y;
    //*y=*t;
    int temp;
    temp= *x;
    *x = *y;
    *y = temp;

}
int main()
{
    int a=15;
    int b=20;
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    zamien(&a,&b);
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    //printf("%d",sizeof(char));
    return 0;
}
