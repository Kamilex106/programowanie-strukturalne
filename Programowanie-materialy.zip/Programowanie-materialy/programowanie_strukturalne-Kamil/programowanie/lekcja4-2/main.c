#include <stdio.h>
#include <stdlib.h>

zlicz(int i){
static int ile=0;
ile += i;
printf("Funkcja zostala wywolana na argumentach o sume %d razy\n",ile);
}
int main()
{
zlicz(5);
zlicz(7);
zlicz(8);

    return 0;
}




//
//#include <stdio.h>
//#include <stdlib.h>
//
//zlicz(){
//static int ile=0;
//ile++;
//printf("Funkcja zostala wywolana %d razy\n",ile);
//}
//int main()
//{
//zlicz();
//zlicz();
//zlicz();
//zlicz();
//zlicz();
//zlicz();
//zlicz();
//
//    return 0;
//}
//
//



