#include <stdio.h>
#include <stdlib.h>

int rekurencja(int n)
{
   if (n<2) {
    return 1;
   }
   int i;
   if(n%2==0) {
    return rekurencja(n-1)+n;
   }
   return rekurencja(n-1)*n;
}
int main()
{
    int x;
    for(x=0;x<10;x++)
    printf("%d\n",rekurencja(x));
    return 0;
}
