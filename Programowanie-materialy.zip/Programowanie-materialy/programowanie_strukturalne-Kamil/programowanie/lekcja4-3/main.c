#include <stdio.h>
#include <stdlib.h>


int rekurencja(int n)
{
   if (n==0) {
    return 1;
   }
   return (rekurencja(n-1)*2)+5;

}
int main()
{
    int x;
    for(x=0;x<100;x++)
    printf("%d\n",rekurencja(x));
    return 0;
}
