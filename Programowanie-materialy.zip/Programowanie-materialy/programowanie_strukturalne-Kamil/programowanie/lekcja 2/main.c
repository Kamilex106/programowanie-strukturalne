#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int a,b,c,d,e,f;
    int W,Wx,Wy;
    float x,y;
    scanf("%d %d %d %d %d %d", &a, &b, &c, &d, &e, &f);
    printf("Zdefiniowales uklad rownan \n%d*x+%d*y-%d\n %d*x+%d*y-%d\n",a,b,c,d,e,f);
    W=a*e-b*d;
    Wx=c*e-b*f;
    Wy=a*f-c*d;
    if(W!=0) {
        x=(float)(Wx/W);
        y=(float)(Wy/W);
        printf("Rozwiazaniem ukladu rownan jest x=%f,y=%f",x,y);
    }
    else if(Wx==0&&Wy==0) {
        printf("uklad nieoznaczony");
    }
    else{
        printf("uklad sprzeczny");
    }

//    int a,b,c,d;
//    float x1,x2;
//
//    scanf("%d %d %d", &a, &b, &c);
//    if(a==1)
//    {
//        print("x^2");
//    }
//    else i(a==-1)
//    {
//        printf("-x^2");
//    }
//    else{
//        printf("%d*x^2");
//    }
//    else{
//        printf("%d*x^2");
//    }
//    if(b==1)
//    {
//        print("+x");
//    }
//    else if(b==-1)
//    {
//        printf("-x");
//    }
//    else if (b>0){
//        printf("+%d*x",b);
//    }
//    else if (b<0){
//        printf("%d*x",b);
//    }
//
//
//
//    if (a>0 && b>0 && c>0) {
//        if (a!=1 && b!=1 && c!=1) {
//            printf("Zdefiniowales rownanie \n%d*x^2+%d*x+%d=0\n",a,b,c);
//        }
//        if (a=1)
//    }
//
//    d=b*b-4*a*c;
//    if (d>0)
//    {
//        x1=(-b-sqrt(d))/(2*a);
//        x2=(-b+sqrt(d))/(2*a);
//        printf("Rozwiazaniem rownania sa x1=%f, x2=%f",x1,x2);
//    }
//    else if (d=0)
//    {
//        x1=(-b)/(2*a);
//        printf("Rozwiazaniem rownania sa x1=%f",x1);
//    }
//    else{
//        printf("Brak rozwiazan");
//    }
//
//
//
//
//
//
//
//
//
//
//
    return 0;
}



//uklad 3 rownan z 3 niewiadomymi PD
//regula sarrusqa (12)) rozpisac

//#include <stdio.h>
//
//float determinant(float matrix[3][3]) {
//    float det = 0;
//    for (int i = 0; i < 3; i++) {
//        det += (matrix[0][i] * (matrix[1][(i+1)%3] * matrix[2][(i+2)%3] - matrix[1][(i+2)%3] * matrix[2][(i+1)%3]));
//    }
//    return det;
//}
//
//int main() {
//    float a[3][3], b[3], x[3], det, det_x, det_y, det_z;
//
//    printf("Podaj wsp�czynniki r�wna�:\n");
//    for (int i = 0; i < 3; i++) {
//        printf("R�wnanie %d: ", i+1);
//        for (int j = 0; j < 3; j++) {
//            scanf("%f", &a[i][j]);
//        }
//        printf("Wynik r�wnania %d: ", i+1);
//        scanf("%f", &b[i]);
//    }
//
//    det = determinant(a);
//
//    if (det == 0) {
//        printf("Uk�ad r�wna� nie ma jednoznacznego rozwi�zania.\n");
//        return 1;
//    }
//
//    float temp[3][3];
//    for (int i = 0; i < 3; i++) {
//        for (int j = 0; j < 3; j++) {
//            temp[i][j] = a[i][j];
//        }
//    }
//
//    for (int i = 0; i < 3; i++) {
//        temp[i][0] = b[i];
//    }
//    det_x = determinant(temp);
//
//    for (int i = 0; i < 3; i++) {
//        temp[i][0] = a[i][0];
//        temp[i][1] = b[i];
//    }
//    det_y = determinant(temp);
//
//    for (int i = 0; i < 3; i++) {
//        temp[i][1] = a[i][1];
//        temp[i][2] = b[i];
//    }
//    det_z = determinant(temp);
//
//    x[0] = det_x / det;
//    x[1] = det_y / det;
//    x[2] = det_z / det;
//
//    printf("Rozwi�zanie uk�adu r�wna� to: x = %f, y = %f, z = %f\n", x[0], x[1], x[2]);
//
//    return 0;
//}
//
