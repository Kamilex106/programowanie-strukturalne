#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int rekurencja(int n)
{
   if (n<2) {
    return 1;
   }
   if (n==1) {
    return 1;
   }
   return rekurencja(n-1)+rekurencja(n-2);

}
void ilorazy(int n)
{
    int i;
    for(i=0;i<=n;i++) {
    printf("a_%d/a_%d=%f\n",i+1,i,(float)(rekurencja(i+1))/rekurencja(i));
   }

}
int main()
{
    ilorazy(20);
    printf("\n Zlota liczba: %f",(1+sqrt(5))/2);
//    int x;
//    for(x=0;x<10;x++)
//    printf("%d\n",rekurencja(x));
    return 0;
}
