#include <stdio.h>
#include <stdlib.h>
int silnia(int x)
{
  if (x==0) {
    return 1;
  }
  return x *silnia(x-1);
}

int main()
{
    int n;
    scanf("%d",&n);
    printf("%d",silnia(n));
    return 0;
}
