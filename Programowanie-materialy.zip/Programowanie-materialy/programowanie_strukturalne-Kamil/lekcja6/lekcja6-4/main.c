#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d\t",tab[i]);
    }
    printf("\n");
}


int suma(unsigned int n,int *tab)
{
    int i;
    int suma=0;
    for(i=0;i<n;i++)
    {
        suma+=tab[i];
    }
    return suma;
}

int sumakwadratow(unsigned int n,int *tab)
{
    int i;
    int suma=0;
    for(i=0;i<n;i++)
    {
        suma+=tab[i]*tab[i];
    }
    return suma;
}

float srednia(unsigned int n,int *tab)
{
    int i;
    float suma=0;
    float srednia;
    for(i=0;i<n;i++)
    {
        suma+=tab[i];
    }
    srednia = suma/n;
    return srednia;
}


float sredniageo(unsigned int n,int *tab)
{
    int i;
    float suma=1;
    for(i=0;i<n;i++)
    {
        suma=suma*tab[i];
    }
    return pow(suma,1.0/n);
}


float sredniahar(unsigned int n,int *tab)
{
    int i;
    float suma=0;
    for(i=0;i<n;i++)
    {
        suma= suma+ 1.0/tab[i];
    }
    return n/suma;
}

int main()
{
    int tablica2[]={7,1,5,2};
    wypisz(4,tablica2);
    //printf("%d",suma(4,tablica2));
     //printf("%d",sumakwadratow(4,tablica2));
     //printf("%f",srednia(4,tablica2));
     //printf("%f.2",sredniageo(4,tablica2));
     printf("%.2f",sredniahar(4,tablica2));

}
