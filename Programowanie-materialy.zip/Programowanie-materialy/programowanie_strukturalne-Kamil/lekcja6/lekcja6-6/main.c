#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d. %d\t",i,tab[i]);
    }
    printf("\n");
}

void przepisz(unsigned int n,int *tab1,int *tab2)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab2[i]=tab1[i];
    }
}

void przepisz_odwrotnie(unsigned int n,int *tab1,int *tab2)
{
    int i;
    int j=n-1;
    for(i=0;i<n;i++,j--)
    {
        tab2[j]=tab1[i];
    }
}

int main()
{
    int tablica[] = {2,8,10,15};
    int tabliczka[] = {2,8,10,15};
    wypisz(4,tablica);
    wypisz(4,tabliczka);
    przepisz_odwrotnie(4,tablica,tabliczka);
    //przepisz(4,tablica,tabliczka);
    wypisz(4,tablica);
    wypisz(4,tabliczka);
}


//i->n-1-i
