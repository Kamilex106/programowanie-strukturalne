#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double x=-9.098;
    printf("Podaj liczbe: ");
    scanf("%lf", &x);
    printf("%lf",fabs(x));
}
