#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    scanf("%d",&x);
    printf("Liczba: %d\n",x);
    return 0;
}
