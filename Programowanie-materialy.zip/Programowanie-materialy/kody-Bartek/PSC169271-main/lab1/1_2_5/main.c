#include <stdio.h>
#include <stdlib.h>

int main()
{
    double x;
    scanf("%lf",&x);
    printf("Liczba: %lf\n",x);
    return 0;
}
