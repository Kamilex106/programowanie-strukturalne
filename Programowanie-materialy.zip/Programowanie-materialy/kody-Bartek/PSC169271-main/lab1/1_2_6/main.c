#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    printf("Podaj liczby: ");
    scanf("%d %d %d",&a,&b,&c);
    printf("%d\n%d\n%d",a,b,c);
    return 0;
}
