#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Bardzo\ndlugi\nnapis ");
    return 0;
}
