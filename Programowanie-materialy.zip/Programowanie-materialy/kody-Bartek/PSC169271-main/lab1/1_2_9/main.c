#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x;
    scanf("%f",&x);
    printf("%f",sqrt(x));
    return 0;
}
