#include <stdio.h>
#include <stdlib.h>

int main()
{
  int a,b,c;
  scanf("%d %d %d",&a,&b,&c);
  double suma=(float)(a+b+c)/3;
  printf("%lf",suma);
}
