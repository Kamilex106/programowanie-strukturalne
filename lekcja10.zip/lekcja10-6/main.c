#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//6.2.21




void wczytaj_kwadratowa(int** t, unsigned int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<n;j++)
        {
            scanf("%d",&t[i][j]);
        }
    }
}


void wypisz_kwadratowa(int **t,unsigned int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<n;j++)
        {
            printf("%d\t",t[i][j]);
        }
        printf("\n");
    }
     printf("\n");
}



int** alokuj_kwadratowa(unsigned int n)
{
    int **t = malloc(n*sizeof(int*));
    int i;
    for(i=0;i<n;i++)
    {
        t[i]=malloc(n*sizeof(int));
    }
    return t;
}


int minimum(int x, int y)
{
    if (x<y)
    {
        return x;
    }
    return y;
}


int minimum_z_czterech(int x, int y, int z, int w)
{
    if(x>=y&&z>=y&&w>=y)
    {
        return y;
    }
    if (y>=x&&z>=x&&w>=x)
    {
        return x
    }
    if (y>=z&&)
}




void** odwroc_wiersze(int **t, int n)
{
    int **t = alokuj_kwadratowa(n);
    int i,j;
    for (i=0;i<(n+1)/2;i++)
    {
        for(j=0;j<(n+1)/2;j++)
        {
            if (i<(n+1)/2&&(n+1)/2)
            {
                t[i][j]=minimum(i,j)+1;
            }
        }
            for(i=(n+1)/2;i<n;i++)
            {
                for (j=0;j<(n+1)/2;j++)
                {
                    t[i][j]=t[n-1-i][j];
                }
            }
            for (i=0;i<n;i++)
            {
            }
        }
    }
    return t;
}





int main() {
int** tablica=rzutki(10);
wypisz_kwadratowa(tablica,10);
}



