#include <stdio.h>
#include <stdlib.h>



void wypisz(int **t,unsigned int n, unsigned int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            printf("%d\t",t[i][j]);
        }
        printf("\n");
    }
}



void wypisz2(unsigned int n, unsigned int m, int t[][m])
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            printf("%d\t",t[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}





void zerujaca(unsigned int n, unsigned int m, int t[][m])
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            t[i][j]=0;

        }

    }
}

int main() {
int tablica[2][3]={{4,7,6},{5,2,9}};
wypisz2(2,3,tablica);
zerujaca(2,3,tablica);
wypisz2(2,3,tablica);




}
