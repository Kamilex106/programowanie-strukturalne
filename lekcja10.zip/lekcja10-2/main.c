#include <stdio.h>
#include <stdlib.h>

//6.2.9

void wczytaj(int** t, unsigned int n, unsigned int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            scanf("%d",&t[i][j]);
        }
    }
}


void wypisz(int **t,unsigned int n, unsigned int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            printf("%d\t",t[i][j]);
        }
        printf("\n");
    }
}

int** alokuj(unsigned int n, unsigned int m)
{
    int **t = malloc(n*sizeof(int*));
    int i;
    for(i=0;i<n;i++)
    {
        t[i]=malloc(m*sizeof(int));
    }
    return t;
}

int zsumuj(unsigned int n, unsigned int m, int t[][m])
{
    int i,j;
    int suma=0;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            suma+= t[i][j];

        }

    }
    return suma;
}

///kolokwium
// np. zsumuj wszystko z nieparzystych wierszy i parzystych kolumn (cos co da sie jakos opisac)
//pd. dla tablicy tablic (6.2.12)

void zerujaca_tablice_tablic(int **t,unsigned int n, unsigned int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            t[i][j]=0;

        }

    }
}

int main() {
int tablica[2][3]={{4,7,6},{5,2,9}};
wypisz(2,3,tablica);
printf("%d",zsumuj(2,3,tablica));
}
