#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d. %d\t",i,tab[i]);
    }
    printf("\n");
}
bool wypiszbool(unsigned int n,bool *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d. %d\t",i,tab[i]);
    }
    printf("\n");
}

void sito_Eratostenesa(unsigned int n)
{
    bool liczby[n];
    int i;
    for (i=0;i<n;i++)
    {
        liczby[i] = true;
    }
    int j,k;

    for(j=2;j<n;j++)
    {
        for (k=2*j;k<n;k=k+j)
        {
            liczby[k] =false;
        }
    }
    wypiszbool(n,liczby);
}

int sito_Eratostenesa_ost(unsigned int n)
{
    bool liczby[n];
    int i;
    int wynik;
    for (i=0;i<n;i++)
    {
        liczby[i] = true;
    }
    int j,k;

    for(j=2;j<n;j++)
    {
        for (k=2*j;k<n;k=k+j)
        {
            liczby[k] =false;
        }
    }
    for(i=0;i<n;i++)
    {
        if(liczby[i])
        {
            wynik=i;
        }
    }
    return wynik;
}


int sito_Eratostenesa_ileliczb(unsigned int n)
{
    bool liczby[n];
    int i;
    int wynik=0;
    for (i=0;i<n;i++)
    {
        liczby[i] = true;
    }
    int j,k;

    for(j=2;j<n;j++)
    {
        for (k=2*j;k<n;k=k+j)
        {
            liczby[k] =false;
        }
    }
    for(i=2;i<n;i++)
    {
        if(liczby[i])
        {
            wynik=wynik+1;
        }
    }
    return wynik;
}


void sito_Eratostenesa_blizniaczo_pierwsze(unsigned int n)
{
    bool liczby[n];
    int i;
    for (i=0;i<n;i++)
    {
        liczby[i] = true;
    }
    int j,k;

    for(j=2;j<n;j++)
    {
        for (k=2*j;k<n;k=k+j)
        {
            liczby[k] =false;
        }
    }

    for (int g=0;g<n;g++)
    {
        if (liczby[g] == 2 + liczby[g+1]) {
            printf("(%d,%d)",liczby[g],liczby[g+1]);
        }
    }
    //wypiszbool(n,liczby);
}



int main()
{
    //int tablica2[]={7,1,5,2};
    //sito_Eratostenesa(100);
    //printf("%d",sito_Eratostenesa_ileliczb(1000));
    sito_Eratostenesa_blizniaczo_pierwsze(100);

}

//ile jest liczb pierwszych do danej liczby (mniejszych)

//pary liczb blizniaczo pierwszych
