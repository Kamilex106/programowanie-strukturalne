#include <stdio.h>
#include <stdlib.h>

void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d\t",tab[i]);
    }
    printf("\n");

void zeruj(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=0;
    }
}

void indeksowanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=i;
    }
}


void podwajanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=2*tab[i];
    }
}



int main()
{
    #include <stdio.h>
#include <stdlib.h>

void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d\t",tab[i]);
    }
    printf("\n");

void zeruj(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=0;
    }
}

void indeksowanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=i;
    }
}


void podwajanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=2*tab[i];
    }
}



int main()
{

    int tablica2[]={7,9,51,-208};
    wypisz(4,tablica2);
    zeruj(4,tablica2);
    wypisz(4,tablica2);
}






