#include <stdio.h>
#include <stdlib.h>

void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d\t",tab[i]);
    }
    printf("\n");
}
void zeruj(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=0;
        printf("%d\t",tab[i]);
    }
}

void indeksowanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=i;
        printf("%d\t",tab[i]);

    }
}


void podwajanie(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab[i]=2*tab[i];
        printf("%d\t",tab[i]);
    }
}


void podwoj_i_zeruj(unsigned int n,int *tab)
{
    int i;
    int a;
    a=n/2;
    a=(n+1)/2;
    for(i=0;i<n;i++)
    {
    tab[i]=2*tab[i];
    }
    for(i=n/2+1;i<n;i++)
    {
         tab[i]=0;
    }

}

void wartoscbezwzgledna(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
       tab[i]=abs(tab[i]);
    }
}



int main()
{

    int tablica2[]={7,9,51,-208};
    wypisz(4,tablica2);
   // zeruj(4,tablica2);
   // wypisz(4,tablica2);
   // podwoj_i_zeruj(5,tablica2);


