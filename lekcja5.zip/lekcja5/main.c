#include <stdio.h>
#include <stdlib.h>

int main()
{
    int liczba=-505;
    printf("Wartosc zmiennej to: %d\n",liczba);
    printf("Adres zmiennej to: %p\n",&liczba);
    int *wskaznik=&liczba;
    printf("Wartosc zmiennej to: %d\n",liczba);
    printf("Adres zmiennej to: %p\n",&liczba);
    printf("Adres przechowywany we wskazniku to: %p\n",wskaznik);
    printf("Wskazywana wartosc to: %d\n",*wskaznik);
    //*a=1; //nie mozna!
    int i=0;
    const int *a=&i;
    int * const b=&i;
    int const * const c=&i;

    *b=1;
    a=b;
    //b=a; //nie mozna zmienic adresu stalego wskaznika

    a=&liczba;
    //b=&liczba; //niedozwolone
    return 0;
}
