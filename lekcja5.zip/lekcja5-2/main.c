#include <stdio.h>
#include <stdlib.h>

int mniejsza(int* x,int* y)
{
    if (*x>*y)
    {
        return *y;
    }
    return *x;
}
int main()
{
    int a=15;
    int b=10;
    printf("%d\n",mniejsza(&a,&b));
    return 0;
}
