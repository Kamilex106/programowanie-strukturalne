#include <stdio.h>
#include <stdlib.h>

void przypisz(int n,int*w)
{
    *w = n;
}
int main()
{
    int x=15;
    przypisz(3,&x);
    printf("%d\n",x);
    return 0;
}
