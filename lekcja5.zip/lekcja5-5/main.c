#include <stdio.h>
#include <stdlib.h>

void zamien(int* x,int* y)
{
    if (*x>*y)
    {
    int temp;
    temp= *x;
    *x = *y;
    *y = temp;
    }
}
int main()
{
    int a=15;
    int b=10;
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    zamien(&a,&b);
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    return 0;
}
