#include <stdio.h>
#include <stdlib.h>

int rekurencja(int n, int m)
{
   if (m==0) {
    return n;
   }
   if(n==0) {
    return m;
   }
   return rekurencja(n-1,m)+rekurencja(n,m-1)+rekurencja(n-1,m-1);


}
int main()
{
    int n,m;
    for(n=0;n<4;n++) {
            for(m=0;m<4;m++) {
                 printf("\n n=%d m=%d rek=%d",n,m,rekurencja(n,m));
            }

    }





//    printf("%d\n",rekurencja(1,3));
//    printf("%d\n",rekurencja(2,2));
//    printf("%d\n",rekurencja(2,1));
//    printf("%d\n",rekurencja(5,7));

    return 0;
}
