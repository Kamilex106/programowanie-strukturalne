#include <stdio.h>
#include <stdlib.h>

int rekurencja(int n)
{
   if (n<2) {
    return 1;
   }
   int suma=0;
   int i;
   for (i=0;i<n;i++)
   {
       suma=suma+rekurencja(i);
   }
   return suma;

}
int main()
{
    int x;
    for(x=0;x<10;x++)
    printf("%d\n",rekurencja(x));
    return 0;
}
