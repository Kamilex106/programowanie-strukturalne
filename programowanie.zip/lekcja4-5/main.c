#include <stdio.h>
#include <stdlib.h>

int rekurencja(int n)
{
   if (n<2) {
    return 1;
   }
   if (n==1) {
    return 1;
   }
   return rekurencja(n-1)+rekurencja(n-2);

}
int main()
{
    int x;
    for(x=0;x<10;x++)
    printf("%d\n",rekurencja(x));
    return 0;
}
