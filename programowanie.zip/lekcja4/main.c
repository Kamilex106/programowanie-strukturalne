#include <stdio.h>
#include <stdlib.h>

unsigned int NWD(unsigned int a, unsigned int b)
{
    int t;
    if(a<b)
    {
        t=a;
        a=b;
        b=t;
    }
    while(a%b!=0)
    {

        t=a;
        a=b;
        b=t%b;
    }
    return b;
}

//maksimum funkcji w zakresie od 0 do 1000 (np. do kolokwium co� dodatkowe)

unsigned int suma(unsigned int n)
{
    int i;
    int suma;
    for(i=2;i<n;i++)
    {
        if(NWD(i,n)==1)
        {
           suma=suma+1;

        }

    }
    return suma;
}

void max_sum()
{
    int i;
    int pom=0;
    int max=0;
    int suma=0;
    for(i=1;i<1000;i++)
    {
        if(max_sum(i)>max) {
            max=max_sum(i);
            pom=i;
        }
    }
    printf("Maksymalna suma liczb wzgl�dnie pierwszych od danej liczby w zakresie");
    printf("od 1 do 999 wynosi %d i jest osi�gana dla %d",max,suma);
}


int min=0;
int liczba=0;
int wynik=0;
    for(int i=100;i<1000;i++) {
        max=sumawp(100);
        if(sumawp(i)<max) {

        }
    }




//wyzej 102 mi powinno byc
//teraz od 100 do 1000 najmniejsza suma dzielnikow













//unsigned int suma(unsigned int n)
//{
//    int i;
//    int suma;
//    for(i=2;i<n;i++)
//    {
//        if(NWD(i,n)==1)
//        {
//           suma=suma+1;
//
//        }
//
//    }
//    return suma;
//}



//
//    while(a!=b)
//       if(a>b)
//           a = a - b;
//       else
//           b = b-a;
//    return a;
//
//

int main()
{
    printf("%d",max_sum);

    return 0;
}
