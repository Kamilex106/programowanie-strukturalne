
//5.2.7

#include <stdio.h>
#include <stdlib.h>

void wytnij(char* napis, int n, int m)
{
    int i, j = 0;

    for(j = 0; napis[j] !=0 ; j++)
    {
        if (j+1>m)
        {
            for (i=0;i+m<j;i++)
            {
                napis[n+1] = napis[m+i+1];
            }
        }
        else if((n<j)&&(j+1<=m))
        {
            napis[n]=0;
        }

    }

}


int main()
{
    char napiszad9[40] = "z tego cos wyciac";
    wytnij(napiszad9,6,8);
    printf(napiszad9);

}
