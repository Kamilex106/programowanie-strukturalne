#include <stdio.h>
#include <stdlib.h>

int zamien_spacje(char* napis)
{
    int i;
    for(i=0;napis[i]!=0;i++)
    {
        if (napis[i]==32)
        {
            napis[i]=95;
        }
    }
}




int main()
{
    //char *napis=malloc(50*sizeof(char));
    //napis = "tu chcemy zmienic spacje";
    char napis[50] = "tu chcemy zmienic spacje";
    printf(napis);
    printf("\n");
    zamien_spacje(napis);
    printf(napis);
    return 0;
}
