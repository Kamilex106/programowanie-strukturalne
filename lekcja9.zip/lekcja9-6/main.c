#include <stdio.h>
#include <stdlib.h>

void wytnijtesameznaki(char *napis1,char *napis2)\
{
    int i,j;
    for (i=0,j=0;napis1[i]!=0;i++)
    {
        if (napis1[i]!=napis2[i])
        {
            napis[j]
        }
    }
    napis1[j]=0
}











int porownajnapisy(char *napis1,char *napis2)
{
    int i;
    int dl1=dlugosc(napis1);
    int dl2=dlugosc(napis2);
    if (dl1 > dl2)
    {
        return 0;
    }
    int wiekszy =0;
    if (dl1>dl2)
    {
        wiekszy = dl1;
    }
    else
    {
        wiekszy = dl2;
    }
        for(i=0;i<=wiekszy-1;i++)
        {
            if (napis1[i]>napis2[i])
            {
                return 0;
            }

        }
        return 1;
    }







int main()
{
    char napiszad131[40]
    printf("Hello world!\n");
    return 0;
}
