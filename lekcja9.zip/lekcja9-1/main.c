#include <stdio.h>
#include <stdlib.h>

//5.2.7

int konkatynacja(char* napis1, char* napis2, char* napis3)
{
    int i,j;
    for(i=0;napis1[i]!=0;i++)
    {
        napis3[i]=napis1[i];
    }
    for(j=0;napis2[j]!=0;j++,i++)
    {
        napis3[i]=napis2[j];
    }
    napis3[i]=0;
}


int main()
{
    char* nap="pierwszy";
    char* napp="drugi";
    char* napis[30];
    konkatynacja(nap,napp,napis);
    printf(napis);
}
