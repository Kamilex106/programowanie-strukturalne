#include <stdio.h>
#include <stdlib.h>
#include <wchar.h> //biblioteka do zamiany liter na duze

//5.2.26


void male_na_duze(char* napis)
{
    int i;
    for(i=0;napis[i]!=0;i++)
    {
        napis[i]=towupper(napis[i]);

    }

}


int main()
{
    char znaki[50] = "ala MA KOTA duze, napisanego o 5kg wagi!";
    printf(znaki);
    male_na_duze(znaki);
    printf("\n");
    printf(znaki);

}
