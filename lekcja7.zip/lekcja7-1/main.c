#include <stdio.h>
#include <stdlib.h>


void suma(unsigned int n, int* tab1, int* tab2, int* tab3)
{
    int i;
    for(i=0;i<n;i++)
    {
        tab3[i]=tab1[i]+tab2[i];
    }
}



int main()
{
    int tab[] = {5,4,2,7};
    int tabb[]={8,1,9,3};
    int tab1[4];
    suma(4,tab,tabb,tab1);




}
