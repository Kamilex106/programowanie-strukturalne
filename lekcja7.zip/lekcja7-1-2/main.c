#include <stdio.h>
#include <stdlib.h>


void maxima(unsigned int n, int* tab1, int* tab2, int* tab3)
{
    int max =0;
    int temp =0;
    int i;
    for(i=0;i<n;i++)
    {
        if (tab2[i]>tab1[i])
        {
            tab3[i]=tab2[i]
        }
        else
        tab3[i]=tab1[i]
    }
}



int main()
{
    int tab[] = {5,4,2,7};
    int tabb[]={8,1,9,3};
    int tab1[4];
    maxima(4,tab,tabb,tab1);




}
