#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d   ",tab[i]);
    }
    printf("\n");
}

void laczenie(unsigned int n, int* tab1, int* tab2,int* tab3)
{

    int i;


    for(i=0;i<n;i++)
    {
        tab3[i] = tab1[i];
    }
    for(i=n;i<2*n;i++)
    {
       tab3[i] = tab2[i-n];
    }
}



int main()
{
    int tab[] = {5,4,2,7};
    int tabb[]={8,1,9,3};
    int tab1[]={0};
    laczenie(4,tab,tabb,tab1);
    wypisz(8,tab1);

}
