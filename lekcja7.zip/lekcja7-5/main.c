
#include <stdio.h>
#include <stdlib.h>


void wypisz(unsigned int n,int *tab)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%d   ",tab[i]);
    }
    printf("\n");
}

void jeden_w_lewo(unsigned int n, int* tab)
{

    int i;
    int temp=tab[0];
    for(i=0;i<n-1;i++)
    {
        tab[i]=tab[i+1];
    }
    tab[n-1]=temp;
}




int main()
{
    int tab1[] = {3,5,12,7,9,4,10,0,5,6};
    wypisz(10,tab1);
    jeden_w_lewo(10,tab1);
    wypisz(10,tab1);

}


//pd 4.2.12 a) i c)
